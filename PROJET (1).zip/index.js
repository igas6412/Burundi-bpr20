// =========================================
// BURUNDI PEOPLE REGISTRY
// INDEX.JS
// =========================================


// =========================================
// ÉLÉMENTS
// =========================================

const loginForm = document.getElementById("loginForm");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const loginError = document.getElementById("loginError");


// =========================================
// 👁️ AFFICHER / CACHER LE MOT DE PASSE
// =========================================

const togglePassword = document.getElementById("togglePassword");

if (togglePassword && passwordInput) {

    togglePassword.addEventListener(
        "click",
        function() {

            if (passwordInput.type === "password") {

                passwordInput.type = "text";

                togglePassword.textContent = "🙈";

                togglePassword.setAttribute(
                    "aria-label",
                    "Cacher le mot de passe"
                );

            } else {

                passwordInput.type = "password";

                togglePassword.textContent = "👁️";

                togglePassword.setAttribute(
                    "aria-label",
                    "Afficher le mot de passe"
                );

            }

        }
    );

}


// =========================================
// COMPTE MANAGER PRINCIPAL
// =========================================

const IGAS_USERNAME = "IGAS";
const IGAS_PASSWORD = "123123";
const session_role="manager national"
const session_type="manager national"
const session_statut="actif"

// =========================================
// CLÉ DES UTILISATEURS
// =========================================

const USERS_KEY = "bpr_utilisateurs";


// =========================================
// RÉCUPÉRER LES COMPTES CRÉÉS
// =========================================

function getUsers() {

    try {

        const data = localStorage.getItem(USERS_KEY);

        if (!data) {
            return [];
        }

        const users = JSON.parse(data);

        return Array.isArray(users) ? users : [];

    } catch (error) {

        console.error(
            "Erreur lors de la lecture des comptes :",
            error
        );

        return [];
    }
}


// =========================================
// SAUVEGARDER LA SESSION
// =========================================

function connecter(username, role) {

    localStorage.setItem(
        "isLoggedIn",
        "true"
    );

    localStorage.setItem(
        "userRole",
        role
    );

    localStorage.setItem(
        "username",
        username
    );
}


// =========================================
// REDIRECTION APRÈS CONNEXION
// =========================================

function allerAccueil() {

    window.location.href = "accueil.html";

}


// =========================================
// AFFICHER UNE ERREUR
// =========================================

function afficherErreur(message) {

    if (loginError) {

        loginError.textContent = message;

    }
}


// =========================================
// CONNEXION
// =========================================

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            // =================================
            // RÉCUPÉRER LES VALEURS
            // =================================

            const username =
                usernameInput.value.trim();

            const password =
                passwordInput.value;


            afficherErreur("");


            // =================================
            // VÉRIFICATION DES CHAMPS
            // =================================

            if (!username || !password) {

                afficherErreur(
                    "Veuillez remplir tous les champs."
                );

                return;
            }


            // =================================
            // COMPTE MANAGER PRINCIPAL
            // =================================
            // Identifiant : IGAS
            // Mot de passe : 123123
            // Rôle : MANAGER
            // =================================

            if (
                username.toLowerCase() ===
                IGAS_USERNAME.toLowerCase()
                &&
                password === IGAS_PASSWORD
            ) {

                connecter(
                    "IGAS",
                    "manager"
                );


                // Nom du manager
                localStorage.setItem(
                    "userName",
                    "IGAS"
                );


                // ID du manager
                localStorage.setItem(
                    "userId",
                    "IGAS"
                );


                // Rôle manager
                localStorage.setItem(
                    "userRole",
                    "manager"
                );


                // Manager connecté
                localStorage.setItem(
                    "bpr_manager_connecte",
                    "true"
                );


                // Province vide pour le manager principal
                localStorage.setItem(
                    "userProvince",
                    ""
                );


                // Aller à l'accueil
                allerAccueil();

                return;
            }


            // =================================
            // COMPTES CRÉÉS PAR LE MANAGER
            // =================================

            const users = getUsers();


            // =================================
            // RECHERCHER LE COMPTE
            // =================================

            const user = users.find(
                function(account) {

                    if (!account) {
                        return false;
                    }


                    // Accepter plusieurs noms de champs
                    // pour rester compatible avec compte.js

                    const savedUsername =
                        String(
                            account.identifiant ||
                            account.username ||
                            account.login ||
                            ""
                        ).trim();


                    const savedPassword =
                        String(
                            account.motDePasse ||
                            account.password ||
                            ""
                        );


                    return (
                        savedUsername.toLowerCase() ===
                        username.toLowerCase()
                        &&
                        savedPassword === password
                    );

                }
            );


            // =================================
            // COMPTE NON TROUVÉ
            // =================================

            if (!user) {

                afficherErreur(
                    "Nom d'utilisateur ou mot de passe incorrect."
                );

                return;
            }


            // =================================
            // VÉRIFIER LE STATUT
            // =================================

            const statut =
                String(
                    user.statut || "actif"
                ).toLowerCase()
                .trim();


            if (
                statut === "inactif"
                ||
                statut === "inactive"
            ) {

                afficherErreur(
                    "Votre compte est inactif. Contactez le manager."
                );

                return;
            }


            // =================================
            // IDENTIFIANT UTILISÉ POUR LA SESSION
            // =================================

            const identifiantConnecte =
                String(
                    user.identifiant ||
                    user.username ||
                    user.login ||
                    ""
                ).trim();


            // =================================
            // DÉTERMINER LE RÔLE
            // =================================

            const roleCompte =
                String(
                    user.role || "Utilisateur"
                ).trim();


            let roleSession = "user";


            if (
                roleCompte.toLowerCase() ===
                "manager"
            ) {

                roleSession = "manager";

            }


            // =================================
            // CONNEXION
            // =================================

            connecter(
                identifiantConnecte,
                roleSession
            );


            // =================================
            // NOM COMPLET
            // =================================

            const nomComplet =
                user.nom ||
                user.nomPrenom ||
                user.nomUtilisateur ||
                identifiantConnecte;


            localStorage.setItem(
                "userName",
                nomComplet
            );


            // =================================
            // ID UTILISATEUR
            // =================================

            localStorage.setItem(
                "userId",
                user.id || identifiantConnecte
            );


            // =================================
            // PROVINCE
            // =================================

            localStorage.setItem(
                "userProvince",
                user.province || ""
            );


            // =================================
            // VÉRIFIER SI C'EST UN MANAGER
            // =================================

            if (roleSession === "manager") {

                localStorage.setItem(
                    "bpr_manager_connecte",
                    "true"
                );

            } else {

                localStorage.removeItem(
                    "bpr_manager_connecte"
                );

            }


            // =================================
            // REDIRECTION
            // =================================

            allerAccueil();

        }
    );

}
