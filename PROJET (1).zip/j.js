/* =========================================================
   BURUNDI PEOPLE REGISTRY
   manager.js — VERSION COMPLETE
========================================================= */

const USERS_KEY = "bpr_utilisateurs";
const MENAGES_KEY = "bpr_menages";
const PERSONNES_KEY = "bpr_personnes";
const VISITEURS_KEY = "bpr_visiteurs";

let tousLesUtilisateurs = [];
let tousLesMenages = [];
let toutesLesPersonnes = [];

let menagesFiltres = [];
let personnesFiltrees = [];


/* =========================================================
   INITIALISATION
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initialiserStockage();
    chargerDonnees();
    initialiserEvenements();
    initialiserFiltresPersonnes();

});


/* =========================================================
   STOCKAGE
========================================================= */

function initialiserStockage() {

    if (!localStorage.getItem(USERS_KEY)) {
        localStorage.setItem(USERS_KEY, JSON.stringify([]));
    }

    if (!localStorage.getItem(MENAGES_KEY)) {
        localStorage.setItem(MENAGES_KEY, JSON.stringify([]));
    }

    if (!localStorage.getItem(PERSONNES_KEY)) {
        localStorage.setItem(PERSONNES_KEY, JSON.stringify([]));
    }

    if (!localStorage.getItem(VISITEURS_KEY)) {
        localStorage.setItem(VISITEURS_KEY, JSON.stringify([]));
}


function lireTableau(key) {

    try {

        const data = JSON.parse(localStorage.getItem(key));

        return Array.isArray(data) ? data : [];

    } catch (e) {

        return [];

    }
}


/* =========================================================
   CHARGEMENT
========================================================= */

function chargerDonnees() {

    tousLesUtilisateurs = lireTableau(USERS_KEY);
    tousLesMenages = lireTableau(MENAGES_KEY);
    toutesLesPersonnes = lireTableau(PERSONNES_KEY);

    menagesFiltres = [...tousLesMenages];
    personnesFiltrees = [...toutesLesPersonnes];

    afficherTout();
}


/* =========================================================
   AFFICHAGE GENERAL
========================================================= */

function afficherTout() {

    afficherStatistiques();

    afficherRapportGlobal();

    afficherUtilisateurs();

    afficherRapportUtilisateurs();

    afficherMenages(menagesFiltres);

    afficherPersonnes(personnesFiltrees);
}


/* =========================================================
   STATISTIQUES
========================================================= */

function afficherStatistiques() {

    const personnes = document.getElementById("totalPersonnes");
    const menages = document.getElementById("totalMenages");
    const utilisateurs = document.getElementById("totalUtilisateurs");
    const provinces = document.getElementById("totalProvinces");

    if (personnes) {
        personnes.textContent = toutesLesPersonnes.length;
    }

    if (menages) {
        menages.textContent = tousLesMenages.length;
    }

    if (utilisateurs) {
        utilisateurs.textContent = tousLesUtilisateurs.length;
    }

    if (provinces) {

        const liste = [
            ...toutesLesPersonnes.map(getProvince),
            ...tousLesMenages.map(getProvince)
        ]
        .map(x => String(x).trim())
        .filter(Boolean);

        provinces.textContent = new Set(liste).size;
    }
}


/* =========================================================
   RAPPORT GLOBAL
========================================================= */

function afficherRapportGlobal() {

    const menages = lireTableau(MENAGES_KEY);
    const personnes = lireTableau(PERSONNES_KEY);
    const utilisateurs = lireTableau(USERS_KEY);

    const totalMenages = document.getElementById("rapportTotalMenages");
    const totalPersonnes = document.getElementById("rapportTotalPersonnes");
    const totalUtilisateurs = document.getElementById("rapportTotalUtilisateurs");
    const moyenne = document.getElementById("rapportMoyenne");

    if (totalMenages) {
        totalMenages.textContent = menages.length;
    }

    if (totalPersonnes) {
        totalPersonnes.textContent = personnes.length;
    }

    if (totalUtilisateurs) {
        totalUtilisateurs.textContent = utilisateurs.length;
    }

    if (moyenne) {

        const valeur = menages.length
            ? personnes.length / menages.length
            : 0;

        moyenne.textContent = valeur.toFixed(2);
    }
}


/* =========================================================
   UTILISATEURS
========================================================= */

function afficherUtilisateurs() {

    const table = document.getElementById("tableUtilisateurs");

    if (!table) return;

    table.innerHTML = `
        <thead>
            <tr>
                <th>Nom</th>
                <th>Identifiant</th>
                <th>Province</th>
                <th>Statut</th>
                <th>Rôle</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
            ${
                tousLesUtilisateurs.length === 0
                ?
                `
                <tr>
                    <td colspan="6">
                        Aucun utilisateur
                    </td>
                </tr>
                `
                :
                tousLesUtilisateurs.map((u, index) => {

                    return `
                        <tr>

                            <td>
                                ${escapeHTML(
                                    u.nom ||
                                    u.name ||
                                    ""
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    u.username ||
                                    u.identifiantUtilisateur ||
                                    ""
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    u.province ||
                                    ""
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    u.statut ||
                                    "Actif"
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    u.role ||
                                    "utilisateur"
                                )}
                            </td>

                            <td>

                                <button
                                    type="button"
                                    onclick="changerStatutUtilisateur(${index})"
                                >
                                    ${
                                        u.statut === "Inactif"
                                        ? "Activer"
                                        : "Désactiver"
                                    }
                                </button>

                            </td>

                        </tr>
                    `;

                }).join("")
            }
        </tbody>
    `;
}


function changerStatutUtilisateur(index) {

    const utilisateurs = lireTableau(USERS_KEY);

    if (!utilisateurs[index]) return;

    utilisateurs[index].statut =
        utilisateurs[index].statut === "Inactif"
        ? "Actif"
        : "Inactif";

    localStorage.setItem(
        USERS_KEY,
        JSON.stringify(utilisateurs)
    );

    chargerDonnees();
}


/* =========================================================
   CREATION UTILISATEUR
========================================================= */

function creerUtilisateur(e) {

    if (e) e.preventDefault();

    const nom = valeur("nomUtilisateur");
    const username = valeur("identifiantUtilisateur");
    const password = valeur("motDePasseUtilisateur");
    const confirmation = valeur("confirmationMotDePasse");
    const province = valeur("provinceUtilisateur");
    const statut = valeur("statutUtilisateur") || "Actif";

    const message =
        document.getElementById("messageUtilisateur");

    if (!nom || !username || !password) {

        afficherMessage(
            message,
            "Veuillez remplir tous les champs obligatoires.",
            "error"
        );

        return;
    }

    if (password !== confirmation) {

        afficherMessage(
            message,
            "Les mots de passe ne correspondent pas.",
            "error"
        );

        return;
    }

    const utilisateurs = lireTableau(USERS_KEY);

    const existe = utilisateurs.some(u =>
        String(
            u.username ||
            u.identifiantUtilisateur ||
            ""
        ).toLowerCase()
        === username.toLowerCase()
    );

    if (existe) {

        afficherMessage(
            message,
            "Cet identifiant existe déjà.",
            "error"
        );

        return;
    }

    const nouvelUtilisateur = {

        id: genererID(),

        nom: nom,

        username: username,

        password: password,

        province: province,

        statut: statut,

        role: "utilisateur",

        dateCreation:
            new Date().toISOString()
    };

    utilisateurs.push(nouvelUtilisateur);

    localStorage.setItem(
        USERS_KEY,
        JSON.stringify(utilisateurs)
    );

    afficherMessage(
        message,
        "Utilisateur créé avec succès.",
        "success"
    );

    const form =
        document.getElementById("formCreerUtilisateur");

    if (form) {
        form.reset();
    }

    chargerDonnees();
}


/* =========================================================
   RAPPORT PAR UTILISATEUR
========================================================= */

function afficherRapportUtilisateurs() {

    const table =
        document.getElementById("tableRapportUtilisateurs");

    if (!table) return;

    const utilisateurs = lireTableau(USERS_KEY);
    const menages = lireTableau(MENAGES_KEY);
    const personnes = lireTableau(PERSONNES_KEY);

    table.innerHTML = `
        <thead>
            <tr>
                <th>Utilisateur</th>
                <th>Province</th>
                <th>Ménages</th>
                <th>Personnes</th>
            </tr>
        </thead>

        <tbody>

            ${
                utilisateurs.length === 0
                ?
                `
                <tr>
                    <td colspan="4">
                        Aucun utilisateur
                    </td>
                </tr>
                `
                :
                utilisateurs.map(u => {

                    const username =
                        u.username ||
                        u.identifiantUtilisateur ||
                        u.nom ||
                        "";

                    const id =
                        u.id ||
                        u.userId ||
                        "";

                    const nbMenages =
                        menages.filter(m =>
                            utilisateurCorrespond(m, username, id)
                        ).length;

                    const nbPersonnes =
                        personnes.filter(p =>
                            utilisateurCorrespond(p, username, id)
                        ).length;

                    return `
                        <tr>

                            <td>
                                ${escapeHTML(username)}
                            </td>

                            <td>
                                ${escapeHTML(
                                    u.province || ""
                                )}
                            </td>

                            <td>
                                ${nbMenages}
                            </td>

                            <td>
                                ${nbPersonnes}
                            </td>

                        </tr>
                    `;

                }).join("")
            }

        </tbody>
    `;
}


function utilisateurCorrespond(obj, username, id) {

    const valeurUtilisateur =
        getUtilisateurMenage(obj);

    if (!valeurUtilisateur) return false;

    return (
        String(valeurUtilisateur).toLowerCase()
        === String(username).toLowerCase()
    )
    ||
    String(valeurUtilisateur)
        === String(id);
}


/* =========================================================
   TABLEAU DES MENAGES
========================================================= */

function afficherMenages(liste) {

    const table =
        document.getElementById("tableMenages");

    const count =
        document.getElementById("countMenages");

    if (!table) return;

    if (count) {
        count.textContent = liste.length;
    }

    table.innerHTML = `
        <thead>

            <tr>

                <th>
                    Nom et prénom du chef du ménage
                </th>

                <th>
                    Province
                </th>

                <th>
                    Commune
                </th>

                <th>
                    Zone
                </th>

                <th>
                    Colline
                </th>

                <th>
                    Sous-colline
                </th>

                <th>
                    Nom et prénom du chef de 10 maisons
                </th>

                <th>
                    Action
                </th>

            </tr>

        </thead>

        <tbody>

            ${
                liste.length === 0
                ?
                `
                <tr>
                    <td colspan="8">
                        Aucun ménage enregistré
                    </td>
                </tr>
                `
                :
                liste.map((menage) => {

                    const id =
                        menage.id ||
                        menage.idMenage ||
                        genererID();

                    return `
                        <tr>

                            <td>
                                ${escapeHTML(
                                    getChefMenage(menage)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getProvince(menage)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getCommune(menage)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getZone(menage)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getColline(menage)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getSousColline(menage)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getChef10(menage)
                                )}
                            </td>

                            <td>

                                <button
                                    class="btn-voir-menage"
                                    type="button"
                                    onclick="voirMenage('${escapeJS(String(id))}')"
                                >
                                    Voir le ménage
                                </button>

                            </td>

                        </tr>
                    `;

                }).join("")
            }

        </tbody>
    `;
}


/* =========================================================
   VOIR LE MENAGE
========================================================= */

function voirMenage(id) {

    const menages =
        lireTableau(MENAGES_KEY);

    const menage =
        menages.find(m =>
            String(
                m.id ||
                m.idMenage ||
                ""
            ) === String(id)
        );

    if (!menage) {

        alert("Ménage introuvable.");

        return;
    }

    const personnes =
        lireTableau(PERSONNES_KEY);

    const chef =
        getChefMenage(menage);

    const membres =
        personnes.filter(personne => {

            const chefPersonne =
                getChefMenage(personne);

            return normaliser(chefPersonne)
                === normaliser(chef);
        });

    let contenu = `

CHEF DU MÉNAGE
${chef}

PROVINCE
${getProvince(menage)}

COMMUNE
${getCommune(menage)}

ZONE
${getZone(menage)}

COLLINE
${getColline(menage)}

SOUS-COLLINE
${getSousColline(menage)}

CHEF DE 10 MAISONS
${getChef10(menage)}

NOMBRE DE PERSONNES
${membres.length}

-------------------------
MEMBRES DU MÉNAGE
-------------------------

`;

    if (membres.length === 0) {

        contenu +=
            "Aucun membre trouvé.";

    } else {

        membres.forEach((personne, index) => {

            contenu +=
                `${index + 1}. ${getNomPersonne(personne)}\n`;

        });
    }

    alert(contenu);
}


/* =========================================================
   TABLEAU DES PERSONNES
========================================================= */

function afficherPersonnes(liste) {

    const table =
        document.getElementById("tablePersonnes");

    const count =
        document.getElementById("countPersonnes");

    if (!table) return;

    if (count) {
        count.textContent = liste.length;
    }

    table.innerHTML = `

        <thead>

            <tr>

                <th>
                    Nom et prénom
                </th>

                <th>
                    Province
                </th>

                <th>
                    Commune
                </th>

                <th>
                    Zone
                </th>

                <th>
                    Colline
                </th>

                <th>
                    Sous-colline
                </th>

                <th>
                    Nom et prénom du chef de 10 maisons
                </th>

            </tr>

        </thead>

        <tbody>

            ${
                liste.length === 0
                ?
                `
                <tr>
                    <td colspan="7">
                        Aucune personne enregistrée
                    </td>
                </tr>
                `
                :
                liste.map(personne => {

                    return `

                        <tr>

                            <td>
                                ${escapeHTML(
                                    getNomPersonne(personne)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getProvince(personne)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getCommune(personne)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getZone(personne)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getColline(personne)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getSousColline(personne)
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    getChef10(personne)
                                )}
                            </td>

                        </tr>

                    `;

                }).join("")
            }

        </tbody>
    `;
}


/* =========================================================
   FILTRES GENERAUX
========================================================= */

function appliquerFiltres() {

    const utilisateur =
        valeur("filtreUtilisateur").toLowerCase();

    const province =
        valeur("filtreProvince");

    const commune =
        valeur("filtreCommune");

    const zone =
        valeur("filtreZone");

    const colline =
        valeur("filtreColline");

    const sousColline =
        valeur("filtreSousColline");

    const chef10 =
        valeur("filtreChef10");

    const recherche =
        valeur("rechercheManager").toLowerCase();

    menagesFiltres =
        tousLesMenages.filter(m => {

            const texte = [

                getChefMenage(m),
                getProvince(m),
                getCommune(m),
                getZone(m),
                getColline(m),
                getSousColline(m),
                getChef10(m),
                getUtilisateurMenage(m)

            ].join(" ").toLowerCase();

            return (

                (!utilisateur ||
                    texte.includes(utilisateur))

                &&

                (!province ||
                    getProvince(m) === province)

                &&

                (!commune ||
                    getCommune(m) === commune)

                &&

                (!zone ||
                    getZone(m) === zone)

                &&

                (!colline ||
                    getColline(m) === colline)

                &&

                (!sousColline ||
                    getSousColline(m) === sousColline)

                &&

                (!chef10 ||
                    getChef10(m) === chef10)

                &&

                (!recherche ||
                    texte.includes(recherche))

            );

        });

    afficherMenages(menagesFiltres);
}


/* =========================================================
   RESET FILTRES
========================================================= */

function resetFiltres() {

    const ids = [

        "filtreUtilisateur",
        "filtreProvince",
        "filtreCommune",
        "filtreZone",
        "filtreColline",
        "filtreSousColline",
        "filtreChef10",
        "rechercheManager"

    ];

    ids.forEach(id => {

        const element =
            document.getElementById(id);

        if (element) {
            element.value = "";
        }

    });

    menagesFiltres =
        [...tousLesMenages];

    afficherMenages(menagesFiltres);
}


/* =========================================================
   FILTRES PERSONNES
========================================================= */

function rechercherPersonnes() {

    const pays =
        valeur("filtrePersonnePays").toLowerCase();

    const province =
        valeur("filtrePersonneProvince");

    const commune =
        valeur("filtrePersonneCommune");

    const zone =
        valeur("filtrePersonneZone");

    const colline =
        valeur("filtrePersonneColline");

    const sousColline =
        valeur("filtrePersonneSousColline");

    const chef10 =
        valeur("filtrePersonneChef10");

    const recherche =
        valeur("recherchePersonnes").toLowerCase();

    personnesFiltrees =
        toutesLesPersonnes.filter(personne => {

            const texte = [

                getNomPersonne(personne),
                getPays(personne),
                getProvince(personne),
                getCommune(personne),
                getZone(personne),
                getColline(personne),
                getSousColline(personne),
                getChef10(personne)

            ].join(" ").toLowerCase();

            return (

                (!pays ||
                    getPays(personne)
                        .toLowerCase()
                        .includes(pays))

                &&

                (!province ||
                    getProvince(personne) === province)

                &&

                (!commune ||
                    getCommune(personne) === commune)

                &&

                (!zone ||
                    getZone(personne) === zone)

                &&

                (!colline ||
                    getColline(personne) === colline)

                &&

                (!sousColline ||
                    getSousColline(personne) === sousColline)

                &&

                (!chef10 ||
                    getChef10(personne) === chef10)

                &&

                (!recherche ||
                    texte.includes(recherche))

            );

        });

    afficherPersonnes(personnesFiltrees);
}


function resetRecherchePersonnes() {

    const ids = [

        "filtrePersonnePays",
        "filtrePersonneProvince",
        "filtrePersonneCommune",
        "filtrePersonneZone",
        "filtrePersonneColline",
        "filtrePersonneSousColline",
        "filtrePersonneChef10",
        "recherchePersonnes"

    ];

    ids.forEach(id => {

        const element =
            document.getElementById(id);

        if (element) {
            element.value = "";
        }

    });

    personnesFiltrees =
        [...toutesLesPersonnes];

    afficherPersonnes(personnesFiltrees);

    initialiserFiltresPersonnes();
}


/* =========================================================
   FILTRES CASCADES PERSONNES
========================================================= */

function initialiserFiltresPersonnes() {

    remplirSelectUnique(
        "filtrePersonneProvince",
        toutesLesPersonnes.map(getProvince)
    );

    remplirSelectUnique(
        "filtrePersonneChef10",
        toutesLesPersonnes.map(getChef10)
    );

    const province =
        document.getElementById(
            "filtrePersonneProvince"
        );

    const commune =
        document.getElementById(
            "filtrePersonneCommune"
        );

    const zone =
        document.getElementById(
            "filtrePersonneZone"
        );

    const colline =
        document.getElementById(
            "filtrePersonneColline"
        );

    if (province) {

        province.addEventListener("change", () => {

            const liste =
                toutesLesPersonnes.filter(p =>
                    !province.value ||
                    getProvince(p) === province.value
                );

            remplirSelectUnique(
                "filtrePersonneCommune",
                liste.map(getCommune)
            );

            remplirSelectUnique(
                "filtrePersonneZone",
                []
            );

            remplirSelectUnique(
                "filtrePersonneColline",
                []
            );

            remplirSelectUnique(
                "filtrePersonneSousColline",
                []
            );

        });

    }


    if (commune) {

        commune.addEventListener("change", () => {

            const liste =
                toutesLesPersonnes.filter(p =>

                    (!province.value ||
                        getProvince(p) === province.value)

                    &&

                    (!commune.value ||
                        getCommune(p) === commune.value)

                );

            remplirSelectUnique(
                "filtrePersonneZone",
                liste.map(getZone)
            );

        });

    }


    if (zone) {

        zone.addEventListener("change", () => {

            const liste =
                toutesLesPersonnes.filter(p =>

                    (!province.value ||
                        getProvince(p) === province.value)

                    &&

                    (!commune.value ||
                        getCommune(p) === commune.value)

                    &&

                    (!zone.value ||
                        getZone(p) === zone.value)

                );

            remplirSelectUnique(
                "filtrePersonneColline",
                liste.map(getColline)
            );

        });

    }


    if (colline) {

        colline.addEventListener("change", () => {

            const liste =
                toutesLesPersonnes.filter(p =>

                    (!province.value ||
                        getProvince(p) === province.value)

                    &&

                    (!commune.value ||
                        getCommune(p) === commune.value)

                    &&

                    (!zone.value ||
                        getZone(p) === zone.value)

                    &&

                    (!colline.value ||
                        getColline(p) === colline.value)

                );

            remplirSelectUnique(
                "filtrePersonneSousColline",
                liste.map(getSousColline)
            );

        });

    }
}


/* =========================================================
   REMPLIR SELECT
========================================================= */

function remplirSelectUnique(id, valeurs) {

    const select =
        document.getElementById(id);

    if (!select) return;

    const ancienneValeur =
        select.value;

    const uniques = [
        ...new Set(
            valeurs
                .map(v => String(v || "").trim())
                .filter(Boolean)
        )
    ].sort();

    select.innerHTML =
        `<option value="">Tous</option>`;

    uniques.forEach(valeurOption => {

        const option =
            document.createElement("option");

        option.value =
            valeurOption;

        option.textContent =
            valeurOption;

        select.appendChild(option);

    });

    if (uniques.includes(ancienneValeur)) {
        select.value = ancienneValeur;
    }
}


/* =========================================================
   EVENEMENTS
========================================================= */

function initialiserEvenements() {

    const form =
        document.getElementById(
            "formCreerUtilisateur"
        );

    if (form) {
        form.addEventListener(
            "submit",
            creerUtilisateur
        );
    }


    const btnFiltres =
        document.getElementById(
            "btnAppliquerFiltres"
        );

    if (btnFiltres) {
        btnFiltres.addEventListener(
            "click",
            appliquerFiltres
        );
    }


    const btnReset =
        document.getElementById(
            "btnResetFiltres"
        );

    if (btnReset) {
        btnReset.addEventListener(
            "click",
            resetFiltres
        );
    }


    const btnRecherche =
        document.getElementById(
            "btnRecherchePersonnes"
        );

    if (btnRecherche) {
        btnRecherche.addEventListener(
            "click",
            rechercherPersonnes
        );
    }


    const btnResetPersonnes =
        document.getElementById(
            "btnResetRecherchePersonnes"
        );

    if (btnResetPersonnes) {
        btnResetPersonnes.addEventListener(
            "click",
            resetRecherchePersonnes
        );
    }


    const recherche =
        document.getElementById(
            "recherchePersonnes"
        );

    if (recherche) {

        recherche.addEventListener(
            "input",
            rechercherPersonnes
        );

    }


    const actualiser =
        document.getElementById(
            "btnActualiser"
        );

    if (actualiser) {

        actualiser.addEventListener(
            "click",
            () => {

                chargerDonnees();

            }
        );

    }


    const synchroniser =
        document.getElementById(
            "btnSynchroniser"
        );

    if (synchroniser) {

        synchroniser.addEventListener(
            "click",
            synchroniserDonnees
        );

    }


    const sync =
        document.getElementById(
            "btnLancerSynchronisation"
        );

    if (sync) {

        sync.addEventListener(
            "click",
            synchroniserDonnees
        );

    }


    const exportCSV =
        document.getElementById(
            "btnExportPersonnesCSV"
        );

    if (exportCSV) {

        exportCSV.addEventListener(
            "click",
            exporterPersonnesCSV
        );

    }


    const exportPDF =
        document.getElementById(
            "btnExportPersonnesPDF"
        );

    if (exportPDF) {

        exportPDF.addEventListener(
            "click",
            exporterPersonnesPDF
        );

    }


    const exportGlobal =
        document.getElementById(
            "btnExportCSV"
        );

    if (exportGlobal) {

        exportGlobal.addEventListener(
            "click",
            exporterCSV
        );

    }


    const exportPDFGlobal =
        document.getElementById(
            "btnExportPDF"
        );

    if (exportPDFGlobal) {

        exportPDFGlobal.addEventListener(
            "click",
            exporterPDF
        );

    }


    const logout =
        document.getElementById(
            "btnDeconnexion"
        );

    if (logout) {

        logout.addEventListener(
            "click",
            e => {

                e.preventDefault();

                localStorage.removeItem(
                    "bpr_manager_connecte"
                );

                localStorage.removeItem(
                    "isLoggedIn"
                );

                localStorage.removeItem(
                    "userRole"
                );

                window.location.href =
                    "index.html";

            }
        );

    }

}


/* =========================================================
   SYNCHRONISATION
========================================================= */

function synchroniserDonnees() {

    const status =
        document.getElementById("syncStatus");

    const message =
        document.getElementById(
            "messageSynchronisation"
        );

    if (status) {
        status.textContent =
            "Synchronisation en cours...";
    }

    if (message) {
        message.textContent =
            "Synchronisation en cours...";
    }

    setTimeout(() => {

        chargerDonnees();

        const date =
            new Date().toLocaleString("fr-FR");

        if (status) {
            status.textContent =
                "Synchronisé : " + date;
        }

        if (message) {
            message.textContent =
                "Synchronisation terminée.";
        }

    }, 500);
}


/* =========================================================
   EXPORT CSV PERSONNES
========================================================= */

function exporterPersonnesCSV() {

    const lignes = [];

    lignes.push([
        "Nom et prénom",
        "Province",
        "Commune",
        "Zone",
        "Colline",
        "Sous-colline",
        "Nom et prénom du chef de 10 maisons"
    ]);

    personnesFiltrees.forEach(p => {

        lignes.push([

            getNomPersonne(p),
            getProvince(p),
            getCommune(p),
            getZone(p),
            getColline(p),
            getSousColline(p),
            getChef10(p)

        ]);

    });

    telechargerCSV(
        lignes,
        "personnes_enregistrees.csv"
    );
}


/* =========================================================
   EXPORT CSV GENERAL
========================================================= */

function exporterCSV() {

    const lignes = [];

    lignes.push([
        "Nom et prénom",
        "Province",
        "Commune",
        "Zone",
        "Colline",
        "Sous-colline",
        "Chef de 10 maisons"
    ]);

    toutesLesPersonnes.forEach(p => {

        lignes.push([

            getNomPersonne(p),
            getProvince(p),
            getCommune(p),
            getZone(p),
            getColline(p),
            getSousColline(p),
            getChef10(p)

        ]);

    });

    telechargerCSV(
        lignes,
        "burundi_people_registry.csv"
    );
}


function telechargerCSV(lignes, nomFichier) {

    const csv =
        "\uFEFF" +
        lignes.map(ligne =>
            ligne.map(cellule =>
                `"${String(cellule ?? "")
                    .replace(/"/g, '""')}"`
            ).join(";")
        ).join("\n");

    const blob =
        new Blob(
            [csv],
            {
                type:
                    "text/csv;charset=utf-8;"
            }
        );

    const url =
        URL.createObjectURL(blob);

    const a =
        document.createElement("a");

    a.href = url;

    a.download =
        nomFichier;

    document.body.appendChild(a);

    a.click();

    a.remove();

    URL.revokeObjectURL(url);
}


/* =========================================================
   EXPORT PDF PERSONNES
========================================================= */

function exporterPersonnesPDF() {

    if (
        typeof window.jspdf === "undefined"
        &&
        typeof window.jsPDF === "undefined"
    ) {

        alert(
            "La bibliothèque PDF n'est pas chargée."
        );

        return;
    }

    const PDF =
        window.jspdf
            ? window.jspdf.jsPDF
            : window.jsPDF;

    const doc =
        new PDF();

    doc.setFontSize(14);

    doc.text(
        "Personnes enregistrées",
        14,
        15
    );

    let y = 28;

    doc.setFontSize(8);

    personnesFiltrees.forEach((p, index) => {

        const ligne =
            `${index + 1}. ` +
            `${getNomPersonne(p)} | ` +
            `${getProvince(p)} | ` +
            `${getCommune(p)} | ` +
            `${getZone(p)} | ` +
            `${getColline(p)} | ` +
            `${getSousColline(p)} | ` +
            `${getChef10(p)}`;

        const morceaux =
            doc.splitTextToSize(
                ligne,
                180
            );

        doc.text(
            morceaux,
            14,
            y
        );

        y +=
            morceaux.length * 4 + 3;

        if (y > 280) {

            doc.addPage();

            y = 15;

        }

    });

    doc.save(
        "personnes_enregistrees.pdf"
    );
}


/* =========================================================
   EXPORT PDF GENERAL
========================================================= */

function exporterPDF() {

    if (
        typeof window.jspdf === "undefined"
        &&
        typeof window.jsPDF === "undefined"
    ) {

        alert(
            "La bibliothèque PDF n'est pas chargée."
        );

        return;
    }

    const PDF =
        window.jspdf
            ? window.jspdf.jsPDF
            : window.jsPDF;

    const doc =
        new PDF();

    doc.setFontSize(16);

    doc.text(
        "BURUNDI PEOPLE REGISTRY",
        14,
        15
    );

    doc.setFontSize(10);

    doc.text(
        `Personnes : ${toutesLesPersonnes.length}`,
        14,
        25
    );

    doc.text(
        `Ménages : ${tousLesMenages.length}`,
        14,
        32
    );

    doc.text(
        `Utilisateurs : ${tousLesUtilisateurs.length}`,
        14,
        39
    );

    doc.save(
        "burundi_people_registry.pdf"
    );
}


/* =========================================================
   FONCTIONS GETTERS
========================================================= */

function getNomPersonne(p) {

    return p.nomPrenom ||
        p.nomComplet ||
        p.nomEtPrenom ||
        p.nom_prenom ||
        p.nom ||
        p.fullName ||
        p.name ||
        "";
}


function getChefMenage(m) {

    return m.chefMenage ||
        m.nomChefMenage ||
        m.chef_de_menage ||
        m.chef ||
        m.nomChef ||
        m.chefNom ||
        "";
}


function getProvince(o) {

    return o.province ||
        o.nomProvince ||
        "";
}


function getCommune(o) {

    return o.commune ||
        o.nomCommune ||
        "";
}


function getZone(o) {

    return o.zone ||
        o.nomZone ||
        "";
}


function getColline(o) {

    return o.colline ||
        o.nomColline ||
        "";
}


function getSousColline(o) {

    return o.sousColline ||
        o.sous_colline ||
        o.nomSousColline ||
        "";
}


function getChef10(o) {

    return o.chef10 ||
        o.chefDe10Maisons ||
        o.chef10Maisons ||
        o.chefDe10 ||
        o.chef_dix ||
        "";
}


function getPays(o) {

    return o.pays ||
        o.country ||
        o.nomPays ||
        "";
}


function getUtilisateurMenage(o) {

    return o.username ||
        o.identifiantUtilisateur ||
        o.utilisateur ||
        o.userId ||
        o.idUtilisateur ||
        o.createdBy ||
        "";
}


/* =========================================================
   UTILITAIRES
========================================================= */

function valeur(id) {

    const element =
        document.getElementById(id);

    return element
        ? String(element.value || "").trim()
        : "";
}


function genererID() {

    return Date.now().toString(36)
        + Math.random()
            .toString(36)
            .substring(2, 8);
}


function normaliser(value) {

    return String(value || "")
        .trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
}


function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function escapeJS(value) {

    return String(value)
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "\\'");
}


function afficherMessage(
    element,
    message,
    type
) {

    if (!element) return;

    element.textContent =
        message;

    element.className =
        type === "error"
            ? "message error"
            : "message success";
}


/* =========================================================
   EXPOSER FONCTIONS AU HTML
========================================================= */

window.voirMenage =
    voirMenage;

window.changerStatutUtilisateur =
    changerStatutUtilisateur;

window.creerUtilisateur =
    creerUtilisateur;

window.appliquerFiltres =
    appliquerFiltres;

window.resetFiltres =
    resetFiltres;

window.rechercherPersonnes =
    rechercherPersonnes;

window.resetRecherchePersonnes =
    resetRecherchePersonnes;

window.exporterPersonnesCSV =
    exporterPersonnesCSV;

window.exporterPersonnesPDF =
    exporterPersonnesPDF;

window.exporterCSV =
    exporterCSV;

window.exporterPDF =
    exporterPDF;

window.synchroniserDonnees =
    synchroniserDonnees;
Iyi ni manager.js yuzuye. Ikintu nyamukuru twakosoye ni uko # itakigaragara kandi tableaux zifise exactement:
Personnes : Nom et prénom → Province → Commune → Zone → Colline → Sous-colline → Chef de 10 maisons.
Ménages : Chef du ménage → Province → Commune → Zone → Colline → Sous-colline → Chef de 10 maisons → Voir le ménage.
Kwamamaza