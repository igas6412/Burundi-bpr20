/* =========================================================
   BURUNDI PEOPLE REGISTRY
   COMPTE.JS
   GESTION DES COMPTES UTILISATEURS ET MANAGERS
   ========================================================= */

const UTILISATEURS_KEY = "bpr_utilisateurs";

let utilisateurs = [];
let utilisateurEnModification = null;


/* =========================================================
   1. DONNEES ADMINISTRATIVES
   =========================================================
   5 PROVINCES
   42 COMMUNES
   ========================================================= */

const COMMUNES_PAR_PROVINCE = {

    Buhumuza: [
        "Butaganzwa",
        "Butihinda",
        "Cankuzo",
        "Gisagara",
        "Gisuru",
        "Muyinga",
        "Ruyigi"
    ],

    Bujumbura: [
        "Bubanza",
        "Bukinanyana",
        "Cibitoke",
        "Isare",
        "Mpanda",
        "Mugere",
        "Mugina",
        "Muhuta",
        "Mukaza",
        "Ntahangwa",
        "Rwibaga"
    ],

    Burunga: [
        "Bururi",
        "Makamba",
        "Matana",
        "Musongati",
        "Nyanza",
        "Rumonge",
        "Rutana"
    ],

    Butanyerera: [
        "Busoni",
        "Kayanza",
        "Kiremba",
        "Kirundo",
        "Matongo",
        "Muhanga",
        "Ngozi",
        "Tangara"
    ],

    Gitega: [
        "Bugendana",
        "Gishubi",
        "Gitega",
        "Karusi",
        "Kiganda",
        "Muramvya",
        "Mwaro",
        "Nyabihanga",
        "Shombo"
    ]
};


/* =========================================================
   2. DONNEES ZONES / COLLINES
   =========================================================
   Si BURUNDI_GEO existe dans database.js ou burundi-geo.js,
   le programme l'utilise automatiquement.

   Format attendu :

   BURUNDI_GEO = {
       Buhumuza: {
           Butaganzwa: {
               Bisinde: [
                   "Bisinde",
                   "Bugarama"
               ]
           }
       }
   }

   ========================================================= */

const TERRITOIRES =
    window.BURUNDI_GEO ||
    window.TERRITOIRES ||
    JSON.parse(localStorage.getItem("bpr_territoires") || "null") ||
    {};


/* =========================================================
   3. ELEMENTS HTML
   ========================================================= */

const formCreerUtilisateur =
    document.getElementById("formCreerUtilisateur");

const nomUtilisateur =
    document.getElementById("nomUtilisateur");

const identifiantUtilisateur =
    document.getElementById("identifiantUtilisateur");

const motDePasseUtilisateur =
    document.getElementById("motDePasseUtilisateur");

const confirmationMotDePasse =
    document.getElementById("confirmationMotDePasse");

const roleUtilisateur =
    document.getElementById("roleUtilisateur");

const provinceUtilisateur =
    document.getElementById("provinceUtilisateur");

const communeUtilisateur =
    document.getElementById("communeUtilisateur");

const zoneUtilisateur =
    document.getElementById("zoneUtilisateur");

const collineUtilisateur =
    document.getElementById("collineUtilisateur");

const statutUtilisateur =
    document.getElementById("statutUtilisateur");

const tableUtilisateurs =
    document.getElementById("tableUtilisateurs");

const countUtilisateurs =
    document.getElementById("countUtilisateurs");

const messageUtilisateur =
    document.getElementById("messageUtilisateur");

const btnCreerUtilisateur =
    document.getElementById("btnCreerUtilisateur");

const btnAnnulerModification =
    document.getElementById("btnAnnulerModification");


/* =========================================================
   4. LECTURE STORAGE
   ========================================================= */

function lireUtilisateurs() {

    try {

        const data =
            JSON.parse(
                localStorage.getItem(UTILISATEURS_KEY)
            );

        if (Array.isArray(data)) {
            utilisateurs = data;
        } else {
            utilisateurs = [];
        }

    } catch (erreur) {

        console.error(
            "Erreur lecture utilisateurs :",
            erreur
        );

        utilisateurs = [];
    }
}


/* =========================================================
   5. SAUVEGARDE
   ========================================================= */

function sauvegarderUtilisateurs() {

    localStorage.setItem(
        UTILISATEURS_KEY,
        JSON.stringify(utilisateurs)
    );
}


/* =========================================================
   6. VERIFICATION MANAGER
   ========================================================= */

function verifierManager() {

    const session =
        JSON.parse(
            localStorage.getItem("bpr_session") || "null"
        );

    if (!session) {

        afficherMessage(
            "Vous devez être connecté.",
            "error"
        );

        return false;
    }

    const role =
        String(
            session.role ||
            session.type ||
            session.statut ||
            ""
        )
        .trim()
        .toLowerCase();

    const rolesAutorises = [
        "manager",
        "manager national",
        "manager provincial",
        "manager communal",
        "manager zonal"
    ];

    if (!rolesAutorises.includes(role)) {

        afficherMessage(
            "Accès refusé : cette page est réservée aux managers.",
            "error"
        );

        return false;
    }

    return true;
}


/* =========================================================
   7. AFFICHER NOMBRE DE COMPTES
   ========================================================= */

function afficherNombreComptes() {

    if (countUtilisateurs) {

        countUtilisateurs.textContent =
            utilisateurs.length;
    }
}


/* =========================================================
   8. ECHAPPER HTML
   ========================================================= */

function echapperHTML(valeur) {

    if (
        valeur === null ||
        valeur === undefined
    ) {
        return "";
    }

    return String(valeur)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================================================
   9. AFFICHER LES COMPTES
   ========================================================= */

function afficherUtilisateurs() {

    if (!tableUtilisateurs) {
        return;
    }

    if (utilisateurs.length === 0) {

        tableUtilisateurs.innerHTML = `
            <tr>
                <td colspan="10">
                    Aucun compte enregistré.
                </td>
            </tr>
        `;

        afficherNombreComptes();

        return;
    }

    tableUtilisateurs.innerHTML =
        utilisateurs.map((utilisateur, index) => {

            const date =
                utilisateur.dateCreation ||
                utilisateur.date ||
                "";

            return `
                <tr>

                    <td>
                        ${echapperHTML(
                            utilisateur.nom ||
                            utilisateur.nomUtilisateur ||
                            ""
                        )}
                    </td>

                    <td>
                        ${echapperHTML(
                            utilisateur.identifiant ||
                            utilisateur.username ||
                            ""
                        )}
                    </td>

                    <td>
                        ${echapperHTML(
                            utilisateur.role ||
                            "Utilisateur"
                        )}
                    </td>

                    <td>
                        ${echapperHTML(
                            utilisateur.province ||
                            ""
                        )}
                    </td>

                    <td>
                        ${echapperHTML(
                            utilisateur.commune ||
                            ""
                        )}
                    </td>

                    <td>
                        ${echapperHTML(
                            utilisateur.zone ||
                            ""
                        )}
                    </td>

                    <td>
                        ${echapperHTML(
                            utilisateur.colline ||
                            ""
                        )}
                    </td>

                    <td>
                        <span class="${
                            String(
                                utilisateur.statut || ""
                            ).toLowerCase() === "actif"
                                ? "statut-actif"
                                : "statut-inactif"
                        }">
                            ${echapperHTML(
                                utilisateur.statut ||
                                "Actif"
                            )}
                        </span>
                    </td>

                    <td>
                        ${echapperHTML(date)}
                    </td>

                    <td>

                        <button
                            type="button"
                            onclick="modifierUtilisateur(${index})">
                            ✏️ Modifier
                        </button>

                        <button
                            type="button"
                            onclick="supprimerUtilisateur(${index})">
                            🗑️ Supprimer
                        </button>

                    </td>

                </tr>
            `;

        }).join("");

    afficherNombreComptes();
}


/* =========================================================
   10. CHARGER LES COMMUNES
   ========================================================= */

function chargerCommunes() {

    if (!provinceUtilisateur ||
        !communeUtilisateur) {
        return;
    }

    const province =
        provinceUtilisateur.value;

    communeUtilisateur.innerHTML = `
        <option value="">
            Sélectionner une commune
        </option>
    `;

    if (!province) {

        communeUtilisateur.disabled = true;

        viderZones();
        viderCollines();

        return;
    }

    const communes =
        COMMUNES_PAR_PROVINCE[province] || [];

    communes.forEach(commune => {

        const option =
            document.createElement("option");

        option.value = commune;
        option.textContent = commune;

        communeUtilisateur.appendChild(option);
    });

    communeUtilisateur.disabled =
        communes.length === 0;

    viderZones();
    viderCollines();
}


/* =========================================================
   11. CHARGER LES ZONES
   ========================================================= */

function chargerZones() {

    if (!communeUtilisateur ||
        !zoneUtilisateur) {
        return;
    }

    const province =
        provinceUtilisateur.value;

    const commune =
        communeUtilisateur.value;

    zoneUtilisateur.innerHTML = `
        <option value="">
            Sélectionner une zone
        </option>
    `;

    viderCollines();

    if (!province || !commune) {

        zoneUtilisateur.disabled = true;

        return;
    }

    let zones = [];

    const provinceData =
        TERRITOIRES[province];

    if (provinceData) {

        const communeData =
            provinceData.communes
                ? provinceData.communes[commune]
                : provinceData[commune];

        if (communeData) {

            const zonesData =
                communeData.zones ||
                communeData;

            if (
                zonesData &&
                typeof zonesData === "object"
            ) {

                zones =
                    Array.isArray(zonesData)
                        ? zonesData
                        : Object.keys(zonesData);
            }
        }
    }

    zones.forEach(zone => {

        const option =
            document.createElement("option");

        option.value = zone;
        option.textContent = zone;

        zoneUtilisateur.appendChild(option);
    });

    zoneUtilisateur.disabled =
        zones.length === 0;
}


/* =========================================================
   12. CHARGER LES COLLINES
   ========================================================= */

function chargerCollines() {

    if (!provinceUtilisateur ||
        !communeUtilisateur ||
        !zoneUtilisateur ||
        !collineUtilisateur) {
        return;
    }

    const province =
        provinceUtilisateur.value;

    const commune =
        communeUtilisateur.value;

    const zone =
        zoneUtilisateur.value;

    collineUtilisateur.innerHTML = `
        <option value="">
            Sélectionner une colline / quartier
        </option>
    `;

    if (!province ||
        !commune ||
        !zone) {

        collineUtilisateur.disabled = true;

        return;
    }

    let collines = [];

    const provinceData =
        TERRITOIRES[province];

    if (provinceData) {

        const communeData =
            provinceData.communes
                ? provinceData.communes[commune]
                : provinceData[commune];

        if (communeData) {

            const zonesData =
                communeData.zones ||
                communeData;

            const zoneData =
                zonesData[zone];

            if (Array.isArray(zoneData)) {

                collines = zoneData;

            } else if (
                zoneData &&
                Array.isArray(zoneData.collines)
            ) {

                collines =
                    zoneData.collines;

            } else if (
                zoneData &&
                Array.isArray(zoneData.quartiers)
            ) {

                collines =
                    zoneData.quartiers;
            }
        }
    }

    collines.forEach(colline => {

        const option =
            document.createElement("option");

        option.value = colline;
        option.textContent = colline;

        collineUtilisateur.appendChild(option);
    });

    collineUtilisateur.disabled =
        collines.length === 0;
}


/* =========================================================
   13. VIDER ZONES
   ========================================================= */

function viderZones() {

    if (!zoneUtilisateur) {
        return;
    }

    zoneUtilisateur.innerHTML = `
        <option value="">
            Sélectionner une zone
        </option>
    `;

    zoneUtilisateur.disabled = true;
}


/* =========================================================
   14. VIDER COLLINES
   ========================================================= */

function viderCollines() {

    if (!collineUtilisateur) {
        return;
    }

    collineUtilisateur.innerHTML = `
        <option value="">
            Sélectionner une colline / quartier
        </option>
    `;

    collineUtilisateur.disabled = true;
}


/* =========================================================
   15. GESTION DES CHAMPS SELON LE ROLE
   ========================================================= */

function gererChampsSelonRole() {

    if (!roleUtilisateur) {
        return;
    }

    const role =
        roleUtilisateur.value;

    if (role === "Manager National") {

        provinceUtilisateur.value = "";

        provinceUtilisateur.disabled = true;

        communeUtilisateur.disabled = true;
        zoneUtilisateur.disabled = true;
        collineUtilisateur.disabled = true;

        viderZones();
        viderCollines();

        return;
    }

    provinceUtilisateur.disabled = false;

    if (role === "Manager Provincial") {

        communeUtilisateur.value = "";

        zoneUtilisateur.value = "";
        collineUtilisateur.value = "";

        communeUtilisateur.disabled = true;
        zoneUtilisateur.disabled = true;
        collineUtilisateur.disabled = true;

        viderZones();
        viderCollines();

        return;
    }

    if (role === "Manager Communal") {

        communeUtilisateur.disabled = false;

        zoneUtilisateur.value = "";
        collineUtilisateur.value = "";

        zoneUtilisateur.disabled = true;
        collineUtilisateur.disabled = true;

        viderZones();
        viderCollines();

        return;
    }

    if (role === "Manager Zonal") {

        communeUtilisateur.disabled = false;

        zoneUtilisateur.disabled = false;

        collineUtilisateur.value = "";

        collineUtilisateur.disabled = true;

        return;
    }

    /* Utilisateur */

    communeUtilisateur.disabled = false;
    zoneUtilisateur.disabled = false;
    collineUtilisateur.disabled = false;
}


/* =========================================================
   16. VERIFICATION DU TERRITOIRE
   ========================================================= */

function verifierTerritoire(role) {

    if (role === "Manager National") {
        return true;
    }

    if (!provinceUtilisateur.value) {

        afficherMessage(
            "Veuillez sélectionner une province.",
            "error"
        );

        return false;
    }

    if (
        role === "Manager Communal" ||
        role === "Manager Zonal" ||
        role === "Utilisateur"
    ) {

        if (!communeUtilisateur.value) {

            afficherMessage(
                "Veuillez sélectionner une commune.",
                "error"
            );

            return false;
        }
    }

    if (
        role === "Manager Zonal" ||
        role === "Utilisateur"
    ) {

        if (!zoneUtilisateur.value) {

            afficherMessage(
                "Veuillez sélectionner une zone.",
                "error"
            );

            return false;
        }
    }

    if (role === "Utilisateur") {

        if (!collineUtilisateur.value) {

            afficherMessage(
                "Veuillez sélectionner une colline / quartier.",
                "error"
            );

            return false;
        }
    }

    return true;
}


/* =========================================================
   17. CREER UTILISATEUR
   ========================================================= */

function creerUtilisateur(event) {

    event.preventDefault();

    if (!verifierManager()) {
        return;
    }

    const nom =
        nomUtilisateur.value.trim();

    const identifiant =
        identifiantUtilisateur.value.trim();

    const motDePasse =
        motDePasseUtilisateur.value;

    const confirmation =
        confirmationMotDePasse.value;

    const role =
        roleUtilisateur.value;

    const province =
        provinceUtilisateur.value;

    const commune =
        communeUtilisateur.value;

    const zone =
        zoneUtilisateur.value;

    const colline =
        collineUtilisateur.value;

    const statut =
        statutUtilisateur.value;


    /* ===============================
       VALIDATION NOM
       =============================== */

    if (!nom) {

        afficherMessage(
            "Veuillez entrer le nom et prénom.",
            "error"
        );

        return;
    }


    /* ===============================
       VALIDATION IDENTIFIANT
       =============================== */

    if (!identifiant) {

        afficherMessage(
            "Veuillez entrer un identifiant.",
            "error"
        );

        return;
    }


    /* ===============================
       IDENTIFIANT UNIQUE
       =============================== */

    const existe =
        utilisateurs.some(
            (u, index) =>
                String(
                    u.identifiant ||
                    u.username ||
                    ""
                ).toLowerCase() ===
                identifiant.toLowerCase()
                &&
                index !== utilisateurEnModification
        );

    if (existe) {

        afficherMessage(
            "Cet identifiant existe déjà.",
            "error"
        );

        return;
    }


    /* ===============================
       MOT DE PASSE
       =============================== */

    if (!motDePasse) {

        afficherMessage(
            "Veuillez entrer un mot de passe.",
            "error"
        );

        return;
    }


    if (motDePasse !== confirmation) {

        afficherMessage(
            "Les mots de passe ne correspondent pas.",
            "error"
        );

        return;
    }


    /* ===============================
       TERRITOIRE
       =============================== */

    if (!verifierTerritoire(role)) {
        return;
    }


    /* ===============================
       OBJET UTILISATEUR
       =============================== */

    const utilisateur = {

        id:
            utilisateurEnModification !== null
                ? utilisateurs[
                    utilisateurEnModification
                  ].id
                : "USR-" +
                  Date.now(),

        nom: nom,

        nomUtilisateur: nom,

        identifiant: identifiant,

        username: identifiant,

        motDePasse: motDePasse,

        password: motDePasse,

        role: role,

        typeCompte: role,

        province: province,

        commune: commune,

        zone: zone,

        colline: colline,

        statut: statut,

        dateCreation:
            utilisateurEnModification !== null
                ? (
                    utilisateurs[
                        utilisateurEnModification
                    ].dateCreation ||
                    new Date().toLocaleDateString(
                        "fr-FR"
                    )
                  )
                : new Date().toLocaleDateString(
                    "fr-FR"
                  )
    };


    /* ===============================
       MODIFICATION
       =============================== */

    if (utilisateurEnModification !== null) {

        utilisateurs[
            utilisateurEnModification
        ] = utilisateur;

        afficherMessage(
            "Compte modifié avec succès.",
            "success"
        );

    }

    /* ===============================
       CREATION
       =============================== */

    else {

        utilisateurs.push(utilisateur);

        afficherMessage(
            "Compte créé avec succès.",
            "success"
        );
    }


    sauvegarderUtilisateurs();

    afficherUtilisateurs();

    nettoyerFormulaire();

    utilisateurEnModification = null;

    if (btnCreerUtilisateur) {

        btnCreerUtilisateur.textContent =
            "➕ Créer le compte";
    }

    if (btnAnnulerModification) {

        btnAnnulerModification.style.display =
            "none";
    }
}


/* =========================================================
   18. MODIFIER UTILISATEUR
   ========================================================= */

function modifierUtilisateur(index) {

    if (!verifierManager()) {
        return;
    }

    const utilisateur =
        utilisateurs[index];

    if (!utilisateur) {
        return;
    }

    utilisateurEnModification = index;


    nomUtilisateur.value =
        utilisateur.nom ||
        utilisateur.nomUtilisateur ||
        "";

    identifiantUtilisateur.value =
        utilisateur.identifiant ||
        utilisateur.username ||
        "";

    motDePasseUtilisateur.value =
        utilisateur.motDePasse ||
        utilisateur.password ||
        "";

    confirmationMotDePasse.value =
        utilisateur.motDePasse ||
        utilisateur.password ||
        "";

    roleUtilisateur.value =
        utilisateur.role ||
        "Utilisateur";

    provinceUtilisateur.value =
        utilisateur.province ||
        "";

    chargerCommunes();

    communeUtilisateur.value =
        utilisateur.commune ||
        "";

    chargerZones();

    zoneUtilisateur.value =
        utilisateur.zone ||
        "";

    chargerCollines();

    collineUtilisateur.value =
        utilisateur.colline ||
        "";

    statutUtilisateur.value =
        utilisateur.statut ||
        "Actif";

    gererChampsSelonRole();

    if (btnCreerUtilisateur) {

        btnCreerUtilisateur.textContent =
            "💾 Enregistrer les modifications";
    }

    if (btnAnnulerModification) {

        btnAnnulerModification.style.display =
            "inline-block";
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


/* =========================================================
   19. SUPPRIMER UTILISATEUR
   ========================================================= */

function supprimerUtilisateur(index) {

    if (!verifierManager()) {
        return;
    }

    const utilisateur =
        utilisateurs[index];

    if (!utilisateur) {
        return;
    }

    const identifiant =
        utilisateur.identifiant ||
        utilisateur.username ||
        utilisateur.nom ||
        "";

    const confirmation =
        confirm(
            "Voulez-vous vraiment supprimer le compte : " +
            identifiant +
            " ?"
        );

    if (!confirmation) {
        return;
    }

    utilisateurs.splice(index, 1);

    sauvegarderUtilisateurs();

    afficherUtilisateurs();

    afficherMessage(
        "Compte supprimé avec succès.",
        "success"
    );
}


/* =========================================================
   20. ANNULER MODIFICATION
   ========================================================= */

function annulerModification() {

    utilisateurEnModification = null;

    nettoyerFormulaire();

    if (btnCreerUtilisateur) {

        btnCreerUtilisateur.textContent =
            "➕ Créer le compte";
    }

    if (btnAnnulerModification) {

        btnAnnulerModification.style.display =
            "none";
    }

    afficherMessage("", "");
}


/* =========================================================
   21. NETTOYER FORMULAIRE
   ========================================================= */

function nettoyerFormulaire() {

    if (formCreerUtilisateur) {
        formCreerUtilisateur.reset();
    }

    viderZones();
    viderCollines();

    if (communeUtilisateur) {

        communeUtilisateur.innerHTML = `
            <option value="">
                Sélectionner une commune
            </option>
        `;

        communeUtilisateur.disabled = true;
    }

    if (zoneUtilisateur) {
        zoneUtilisateur.disabled = true;
    }

    if (collineUtilisateur) {
        collineUtilisateur.disabled = true;
    }

    if (provinceUtilisateur) {
        provinceUtilisateur.disabled = false;
    }

    if (statutUtilisateur) {
        statutUtilisateur.value = "Actif";
    }

    if (roleUtilisateur) {
        roleUtilisateur.value = "Utilisateur";
    }
}


/* =========================================================
   22. MESSAGE
   ========================================================= */

function afficherMessage(
    message,
    type
) {

    if (!messageUtilisateur) {
        return;
    }

    messageUtilisateur.textContent =
        message;

    messageUtilisateur.className =
        "message";

    if (type) {
        messageUtilisateur.classList.add(type);
    }
}


/* =========================================================
   23. EVENEMENTS
   ========================================================= */

if (formCreerUtilisateur) {

    formCreerUtilisateur.addEventListener(
        "submit",
        creerUtilisateur
    );
}


if (provinceUtilisateur) {

    provinceUtilisateur.addEventListener(
        "change",
        function () {

            chargerCommunes();

            gererChampsSelonRole();
        }
    );
}


if (communeUtilisateur) {

    communeUtilisateur.addEventListener(
        "change",
        function () {

            chargerZones();

            if (
                roleUtilisateur.value ===
                "Utilisateur"
            ) {
                collineUtilisateur.disabled =
                    true;
            }
        }
    );
}


if (zoneUtilisateur) {

    zoneUtilisateur.addEventListener(
        "change",
        function () {

            chargerCollines();
        }
    );
}


if (roleUtilisateur) {

    roleUtilisateur.addEventListener(
        "change",
        function () {

            gererChampsSelonRole();
        }
    );
}


if (btnAnnulerModification) {

    btnAnnulerModification.addEventListener(
        "click",
        annulerModification
    );
}


/* =========================================================
   24. INITIALISATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        lireUtilisateurs();

        afficherNombreComptes();

        afficherUtilisateurs();

        gererChampsSelonRole();

    }
);


/* =========================================================
   25. FONCTIONS DISPONIBLES GLOBALEMENT
   ========================================================= */

window.modifierUtilisateur =
    modifierUtilisateur;

window.supprimerUtilisateur =
    supprimerUtilisateur;

window.annulerModification =
    annulerModification;

window.chargerCommunes =
    chargerCommunes;

window.chargerZones =
    chargerZones;

window.chargerCollines =
    chargerCollines;