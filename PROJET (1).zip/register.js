/* ============================================================
   BURUNDI PEOPLE REGISTRY
   register.js
   ============================================================ */

const MENAGES_KEY = "bpr_menages";
const PERSONNES_KEY = "bpr_personnes";
const VISITEURS_KEY = "bpr_visiteurs";

let modeModification = false;
let menageIdActuel = null;


/* ============================================================
   INITIALISATION
============================================================ */

document.addEventListener("DOMContentLoaded", () => {

    initialiserCommunes();

    initialiserEnfants();

    initialiserParentes();

    initialiserVisiteurs();

    verifierModeModification();

    initialiserFormulaire();

    initialiserBoutonNouveau();

    initialiserDeconnexion();

});


/* ============================================================
   COMMUNES
============================================================ */

function initialiserCommunes() {

    const province =
        document.getElementById("province");

    const commune =
        document.getElementById("commune");

    if (!province || !commune) return;

    const communes  = {



    Buhumuza: [
        "Butaganzwa",
        "Butihinda",
        "Cankuzo",
        "Gisagara",
        "Gisuru",
        "Muyinga",
        "Ruyigi"
    ],

    Bujumbura: [
        "Bubanza",
        "Bukinanyana",
        "Cibitoke",
        "Isare",
        "Mpanda",
        "Mugere",
        "Mugina",
        "Muhuta",
        "Mukaza",
        "Ntahangwa",
        "Rwibaga"
    ],

    Burunga: [
        "Bururi",
        "Makamba",
        "Matana",
        "Musongati",
        "Nyanza",
        "Rumonge",
        "Rutana"
    ],

    Butanyerera: [
        "Busoni",
        "Kayanza",
        "Kiremba",
        "Kirundo",
        "Matongo",
        "Muhanga",
        "Ngozi",
        "Tangara"
    ],

    Gitega: [
        "Bugendana",
        "Gishubi",
        "Gitega",
        "Karusi",
        "Kiganda",
        "Muramvya",
        "Mwaro",
        "Nyabihanga",
        "Shombo"
    ]
};


    province.addEventListener(
        "change",
        () => {

            commune.innerHTML = `
                <option value="">
                    -- Choisir une commune --
                </option>
            `;

            const liste =
                communes[province.value] || [];

            liste.forEach(nom => {

                const option =
                    document.createElement("option");

                option.value = nom;

                option.textContent = nom;

                commune.appendChild(option);

            });

        }
    );

}


/* ============================================================
   ENFANTS
============================================================ */

function initialiserEnfants() {

    const bouton =
        document.getElementById(
            "btnAjouterEnfant"
        );

    if (!bouton) return;

    bouton.addEventListener(
        "click",
        ajouterEnfant
    );

}


function ajouterEnfant(donnees = {}) {

    const liste =
        document.getElementById(
            "listeEnfants"
        );

    if (!liste) return;


    const enfant =
        document.createElement("div");

    enfant.className =
        "member-form enfant-form";


    enfant.innerHTML = `

        <div class="form-grid">

            <div class="form-group">

                <label>
                    Nom et prénom
                </label>

                <input
                    type="text"
                    class="enfant-nom"
                    value="${escapeHTML(
                        donnees.nomPrenom || ""
                    )}"
                    placeholder="Nom et prénom"
                >

            </div>


            <div class="form-group">

                <label>
                    Genre
                </label>

                <select class="enfant-Genre{
                    
                }">

                    <option value="Masculin"
                        ${
                            donnees.sexe === "Masculin"
                            ? "selected"
                            : ""
                        }>
                        Masculin
                    </option>

                    <option value="Féminin"
                        ${
                            donnees.sexe === "Féminin"
                            ? "selected"
                            : ""
                        }>
                        Féminin
                    </option>

                </select>

            </div>


            <div class="form-group">

                <label>
                    Âge
                </label>

                <input
                    type="number"
                    class="enfant-age"
                    min="0"
                    max="150"
                    value="${escapeHTML(
                        donnees.age || ""
                    )}"
                >

            </div>


            <div class="form-group">

                <label>
                    Numéro d'identité
                </label>

                <input
                    type="text"
                    class="enfant-identite"
                    value="${escapeHTML(
                        donnees.identite || ""
                    )}"
                >

            </div>


            <div class="form-group">

                <label>
                    Téléphone
                </label>

                <input
                    type="tel"
                    class="enfant-telephone"
                    value="${escapeHTML(
                        donnees.telephone || ""
                    )}"
                >

            </div>

        


        <button
            type="button"
            class="btn-remove"
        >
            🗑️ Supprimer cet enfant
        </button>

    `;


    enfant
        .querySelector(".btn-remove")
        .addEventListener(
            "click",
            () => enfant.remove()
        );


    liste.appendChild(enfant);

}


/* ============================================================
   PARENTÉS
============================================================ */

function initialiserParentes() {

    const bouton =
        document.getElementById(
            "btnAjouterParente"
        );

    if (!bouton) return;

    bouton.addEventListener(
        "click",
        () => ajouterParente()
    );

}


function ajouterParente(donnees = {}) {

    const liste =
        document.getElementById(
            "listeParentes"
        );

    if (!liste) return;


    const bloc =
        document.createElement("div");

    bloc.className =
        "member-form parente-form";


    bloc.innerHTML = `

        <div class="form-grid">

            <div class="form-group">

                <label>
                    Nom et prénom
                </label>

                <input
                    type="text"
                    class="parente-nom"
                    value="${escapeHTML(
                        donnees.nomPrenom || ""
                    )}"
                >

            </div>


            <div class="form-group">

                <label>
                    Genre
                </label>

                <select class="parente-Genre">

                    <option value="Masculin"
                        ${
                            donnees.sexe === "Masculin"
                            ? "selected"
                            : ""
                        }>
                        Masculin
                    </option>

                    <option value="Féminin"
                        ${
                            donnees.sexe === "Féminin"
                            ? "selected"
                            : ""
                        }>
                        Féminin
                    </option>

                </select>

            </div>
 <div class="form-group">

                <label>
                    Numéro d'identité
                </label>

                <input
                    type="tel"
                    class="enfant-identite"
                    value="${escapeHTML(
                        donnees.identite || ""
                    )}"
                >

            </div>



            <div class="form-group">

                <label>
                    Âge
                </label>

                <input
                    type="number"
                    class="parente-age"
                    min="0"
                    max="150"
                    value="${escapeHTML(
                        donnees.age || ""
                    )}"
                >

            </div>


            <div class="form-group">

                <label>
                    Lien de parenté
                </label>

                <input
                    type="text"
                    class="parente-lien"
                    value="${escapeHTML(
                        donnees.lien || ""
                    )}"
                    placeholder="Frère, sœur, oncle..."
                >

            </div>

        
 <div class="form-group">

                <label>
                    Téléphone
                </label>

                <input
                    type="tel"
                    class="enfant-telephone"
                    value="${escapeHTML(
                        donnees.telephone || ""
                    )}"
                >

            </div>


        <button
            type="button"
            class="btn-remove"
        >
            🗑️ Supprimer cette parenté
        </button>

    `;


    bloc
        .querySelector(".btn-remove")
        .addEventListener(
            "click",
            () => bloc.remove()
        );


    liste.appendChild(bloc);

}


/* ============================================================
   VISITEURS
============================================================ */

function initialiserVisiteurs() {

    const bouton =
        document.getElementById(
            "btnAjouterVisiteur"
        );

    if (!bouton) return;

    bouton.addEventListener(
        "click",
        () => ajouterVisiteur()
    );

}


function ajouterVisiteur(donnees = {}) {

    const liste =
        document.getElementById(
            "listeVisiteurs"
        );

    if (!liste) return;


    const bloc =
        document.createElement("div");

    bloc.className =
        "member-form visiteur-form";


    bloc.innerHTML = `

        <div class="form-grid">

            <div class="form-group">

                <label>
                    Nom et prénom
                </label>

                <input
                    type="text"
                    class="visiteur-nom"
                    value="${escapeHTML(
                        donnees.nomPrenom || ""
                    )}"
                >

            </div>


            <div class="form-group">

                <label>
                    Genre
                </label>

                <select class="visiteur-Genre">

                    <option value="Masculin"
                        ${
                            donnees.sexe === "Masculin"
                            ? "selected"
                            : ""
                        }>
                        Masculin
                    </option>

                    <option value="Féminin"
                        ${
                            donnees.sexe === "Féminin"
                            ? "selected"
                            : ""
                        }>
                        Féminin
                    </option>

                </select>

            </div>


            <div class="form-group">

                <label>
                    Âge
                </label>

                <input
                    type="number"
                    class="visiteur-age"
                    min="0"
                    max="150"
                    value="${escapeHTML(
                        donnees.age || ""
                    )}"
                >

            </div>
 <div class="form-group">

                <label>
                    Numéro d'identité
                </label>

                <input
                    type="tel"
                    class="enfant-identite"
                    value="${escapeHTML(
                        donnees.identite || ""
                    )}"
                >

            </div>



            <div class="form-group">

                <label>
                    Provenance
                </label>

                <input
                    type="text"
                    class="visiteur-provenance"
                    value="${escapeHTML(
                        donnees.provenance || ""
                    )}"
                    placeholder="D'où vient le visiteur ?"
                >

            </div>

        


        <button
            type="button"
            class="btn-remove"
        >
            🗑️ Supprimer ce visiteur
        </button>

    `;


    bloc
        .querySelector(".btn-remove")
        .addEventListener(
            "click",
            () => bloc.remove()
        );


    liste.appendChild(bloc);

}


/* ============================================================
   MODE MODIFICATION
============================================================ */

function verifierModeModification() {

    const params =
        new URLSearchParams(
            window.location.search
        );


    const idURL =
        params.get("edit");


    const idStocke =
        localStorage.getItem(
            "bpr_menage_a_modifier"
        );


    const id =
        idURL || idStocke;


    if (!id) return;


    const menages =
        lireTableau(
            MENAGES_KEY
        );


    const menage =
        menages.find(
            m =>
                String(m.id) ===
                String(id)
        );


    if (!menage) {

        localStorage.removeItem(
            "bpr_menage_a_modifier"
        );

        return;
    }


    modeModification = true;

    menageIdActuel = id;


    remplirFormulaire(
        menage
    );


    const bouton =
        document.getElementById(
            "saveButton"
        );


    if (bouton) {

        bouton.innerHTML =
            "💾 Mettre à jour le ménage";

    }

}


/* ============================================================
   REMPLIR FORMULAIRE
============================================================ */

function remplirFormulaire(menage) {

    setValue(
        "menageId",
        menage.id
    );

    setValue(
        "pays",
        menage.pays || "Burundi"
    );

    setValue(
        "province",
        menage.province
    );


    /* Charger les communes avant de sélectionner */

    const province =
        document.getElementById(
            "province"
        );

    if (province) {

        province.dispatchEvent(
            new Event("change")
        );

    }


    setTimeout(() => {

        setValue(
            "commune",
            menage.commune
        );

    }, 0);


    setValue(
        "zone",
        menage.zone
    );

    setValue(
        "colline",
        menage.colline
    );

    setValue(
        "sousColline",
        menage.sousColline
    );

    setValue(
        "chef10Maisons",
        menage.chef10Maisons ||
        menage.chef10Nom ||
        menage.nomChef10
    );

    setValue(
        "adresse",
        menage.adresse
    );


    const personnes =
        lireTableau(
            PERSONNES_KEY
        );


    const membres =
        personnes.filter(
            p =>
                String(p.menageId) ===
                String(menage.id)
        );


    const pere =
        membres.find(
            p => p.type === "Père"
        );


    const mere =
        membres.find(
            p => p.type === "Mère"
        );


    if (pere) {

        setValue(
            "nomPere",
            pere.nomPrenom
        );

        setValue(
            "agePere",
            pere.age
        );

        setValue(
            "identitePere",
            pere.identite
        );

        setValue(
            "telephonePere",
            pere.telephone
        );

    }


    if (mere) {

        setValue(
            "nomMere",
            mere.nomPrenom
        );

        setValue(
            "ageMere",
            mere.age
        );

        setValue(
            "identiteMere",
            mere.identite
        );

        setValue(
            "telephoneMere",
            mere.telephone
        );

    }


    const listeEnfants =
        document.getElementById(
            "listeEnfants"
        );


    if (listeEnfants) {

        listeEnfants.innerHTML = "";


        membres
            .filter(
                p =>
                    p.type === "Enfant"
            )
            .forEach(
                enfant =>
                    ajouterEnfant(
                        enfant
                    )
            );

    }


    const listeParentes =
        document.getElementById(
            "listeParentes"
        );


    if (listeParentes) {

        listeParentes.innerHTML = "";


        membres
            .filter(
                p =>
                    p.type === "Parenté"
            )
            .forEach(
                parente =>
                    ajouterParente(
                        parente
                    )
            );

    }


    const visiteurs =
        lireTableau(
            VISITEURS_KEY
        );


    const listeVisiteurs =
        document.getElementById(
            "listeVisiteurs"
        );


    if (listeVisiteurs) {

        listeVisiteurs.innerHTML = "";


        visiteurs
            .filter(
                v =>
                    String(v.menageId) ===
                    String(menage.id)
            )
            .forEach(
                visiteur =>
                    ajouterVisiteur(
                        visiteur
                    )
            );

    }

}


/* ============================================================
   FORMULAIRE
============================================================ */

function initialiserFormulaire() {

    const form =
        document.getElementById(
            "personForm"
        );


    if (!form) return;


    form.addEventListener(
        "submit",
        enregistrerMenage
    );

}


/* ============================================================
   ENREGISTRER / METTRE À JOUR
============================================================ */

function enregistrerMenage(event) {

    event.preventDefault();


    const nomPere =
        getValue("nomPere");


    const nomMere =
        getValue("nomMere");


    if (!nomPere.trim()) {

        afficherMessage(
            "❌ Le nom du père est obligatoire.",
            "error"
        );

        return;
    }


    if (!nomMere.trim()) {

        afficherMessage(
            "❌ Le nom de la mère est obligatoire.",
            "error"
        );

        return;
    }


    const id =
        modeModification
        ? menageIdActuel
        : genererID();


    const menages =
        lireTableau(
            MENAGES_KEY
        );


    const menage = {

        id: id,

        pays:
            getValue("pays") ||
            "Burundi",

        province:
            getValue("province"),

        commune:
            getValue("commune"),

        zone:
            getValue("zone"),

        colline:
            getValue("colline"),

        sousColline:
            getValue("sousColline"),

        chef10Maisons:
            getValue("chef10Maisons"),

        chefMenage:
            nomPere,

        adresse:
            getValue("adresse"),

        dateModification:
            new Date().toISOString()

    };


    /* ========================================================
       PÈRE
    ======================================================== */

    const personnes =
        lireTableau(
            PERSONNES_KEY
        );


    const anciennesPersonnes =
        personnes.filter(
            p =>
                String(p.menageId) !==
                String(id)
        );


    const nouvellesPersonnes = [];


    nouvellesPersonnes.push({

        id: genererID(),

        menageId: id,

        type: "Père",

        nomPrenom: nomPere,

        sexe: "Masculin",

        age:
            getValue("agePere"),

        identite:
            getValue("identitePere"),

        telephone:
            getValue("telephonePere"),

        province:
            menage.province,

        commune:
            menage.commune,

        zone:
            menage.zone,

        colline:
            menage.colline,

        sousColline:
            menage.sousColline,

        chef10Maisons:
            menage.chef10Maisons,

        dateEnregistrement:
            new Date().toISOString()

    });


    /* ========================================================
       MÈRE
    ======================================================== */

    nouvellesPersonnes.push({

        id: genererID(),

        menageId: id,

        type: "Mère",

        nomPrenom: nomMere,

        sexe: "Féminin",

        age:
            getValue("ageMere"),

        identite:
            getValue("identiteMere"),

        telephone:
            getValue("telephoneMere"),

        province:
            menage.province,

        commune:
            menage.commune,

        zone:
            menage.zone,

        colline:
            menage.colline,

        sousColline:
            menage.sousColline,

        chef10Maisons:
            menage.chef10Maisons,

        dateEnregistrement:
            new Date().toISOString()

    });


    /* ========================================================
       ENFANTS
    ======================================================== */

    document
        .querySelectorAll(
            ".enfant-form"
        )
        .forEach(
            bloc => {

                const nom =
                    bloc
                        .querySelector(
                            ".enfant-nom"
                        )?.value
                        .trim();


                if (!nom) return;


                nouvellesPersonnes.push({

                    id: genererID(),

                    menageId: id,

                    type: "Enfant",

                    nomPrenom: nom,

                    Genre:
                        bloc.querySelector(
                            ".enfant-Genre"
                        )?.value || "",

                    age:
                        bloc.querySelector(
                            ".enfant-age"
                        )?.value || "",

                    identite:
                        bloc.querySelector(
                            ".enfant-identite"
                        )?.value || "",

                    telephone:
                        bloc.querySelector(
                            ".enfant-telephone"
                        )?.value || "",

                    province:
                        menage.province,

                    commune:
                        menage.commune,

                    zone:
                        menage.zone,

                    colline:
                        menage.colline,

                    sousColline:
                        menage.sousColline,

                    chef10Maisons:
                        menage.chef10Maisons,

                    dateEnregistrement:
                        new Date().toISOString()

                });

            }
        );


    /* ========================================================
       PARENTÉS
    ======================================================== */

    document
        .querySelectorAll(
            ".parente-form"
        )
        .forEach(
            bloc => {

                const nom =
                    bloc
                        .querySelector(
                            ".parente-nom"
                        )?.value
                        .trim();


                if (!nom) return;


                nouvellesPersonnes.push({

                    id: genererID(),

                    menageId: id,

                    type: "Parenté",

                    nomPrenom: nom,

                    Genre:
                        bloc.querySelector(
                            ".parente-Genre"
                        )?.value || "",

                    age:
                        bloc.querySelector(
                            ".parente-age"
                        )?.value || "",

                    lien:
                        bloc.querySelector(
                            ".parente-lien"
                        )?.value || "",

                    province:
                        menage.province,

                    commune:
                        menage.commune,

                    zone:
                        menage.zone,

                    colline:
                        menage.colline,

                    sousColline:
                        menage.sousColline,

                    chef10Maisons:
                        menage.chef10Maisons,

                    dateEnregistrement:
                        new Date().toISOString()

                });

            }
        );


    /* ========================================================
       VISITEURS
    ======================================================== */

    const tousLesVisiteurs =
        lireTableau(
            VISITEURS_KEY
        );


    const anciensVisiteurs =
        tousLesVisiteurs.filter(
            v =>
                String(v.menageId) !==
                String(id)
        );


    const nouveauxVisiteurs = [];


    document
        .querySelectorAll(
            ".visiteur-form"
        )
        .forEach(
            bloc => {

                const nom =
                    bloc
                        .querySelector(
                            ".visiteur-nom"
                        )?.value
                        .trim();


                if (!nom) return;


                nouveauxVisiteurs.push({

                    id: genererID(),

                    menageId: id,

                    nomPrenom: nom,

                    Genre:
                        bloc.querySelector(
                            ".visiteur-Genre"
                        )?.value || "",

                    age:
                        bloc.querySelector(
                            ".visiteur-age"
                        )?.value || "",

                    provenance:
                        bloc.querySelector(
                            ".visiteur-provenance"
                        )?.value || "",

                    province:
                        menage.province,

                    commune:
                        menage.commune,

                    zone:
                        menage.zone,

                    colline:
                        menage.colline,

                    sousColline:
                        menage.sousColline,

                    chef10Maisons:
                        menage.chef10Maisons,

                    dateEnregistrement:
                        new Date().toISOString()

                });

            }
        );


    /* ========================================================
       SAUVEGARDE MÉNAGE
    ======================================================== */

    if (modeModification) {

        const index =
            menages.findIndex(
                m =>
                    String(m.id) ===
                    String(id)
            );


        if (index !== -1) {

            menages[index] =
                {
                    ...menages[index],
                    ...menage,
                    dateModification:
                        new Date().toISOString()
                };

        } else {

            menages.push(
                menage
            );

        }

    } else {

        menage.dateEnregistrement =
            new Date().toISOString();

        menages.push(
            menage
        );

    }


    /* ========================================================
       LOCAL STORAGE
    ======================================================== */

    localStorage.setItem(
        MENAGES_KEY,
        JSON.stringify(
            menages
        )
    );


    localStorage.setItem(
        PERSONNES_KEY,
        JSON.stringify(
            [
                ...anciennesPersonnes,
                ...nouvellesPersonnes
            ]
        )
    );


    localStorage.setItem(
        VISITEURS_KEY,
        JSON.stringify(
            [
                ...anciensVisiteurs,
                ...nouveauxVisiteurs
            ]
        )
    );


    /* ========================================================
       SYNCHRONISATION MANAGER
    ======================================================== */

    localStorage.setItem(
        "bpr_last_update",
        new Date().toISOString()
    );


    localStorage.setItem(
        "bpr_sync",
        "true"
    );


    afficherMessage(
        modeModification
        ? "✅ Ménage mis à jour avec succès."
        : "✅ Ménage enregistré avec succès.",
        "success"
    );


    /*
       Après quelques secondes,
       retour vers la liste des ménages.
    */

    setTimeout(() => {

        localStorage.removeItem(
            "bpr_menage_a_modifier"
        );


        window.location.href =
            "liste.html";

    }, 900);

}


/* ============================================================
   NOUVEAU
============================================================ */

function initialiserBoutonNouveau() {

    const bouton =
        document.getElementById(
            "btnNouveau"
        );


    if (!bouton) return;


    bouton.addEventListener(
        "click",
        () => {

            localStorage.removeItem(
                "bpr_menage_a_modifier"
            );


            window.location.href =
                "inscription.html";

        }
    );

}


/* ============================================================
   DÉCONNEXION
============================================================ */

function initialiserDeconnexion() {

    const bouton =
        document.getElementById(
            "btnDeconnexion"
        );


    if (!bouton) return;


    bouton.addEventListener(
        "click",
        () => {

            const confirmation =
                confirm(
                    "Voulez-vous vous déconnecter ?"
                );


            if (!confirmation) return;


            localStorage.removeItem(
                "bpr_current_user"
            );


            window.location.href =
                "index.html";

        }
    );

}


/* ============================================================
   MESSAGE
============================================================ */

function afficherMessage(
    texte,
    type
) {

    const message =
        document.getElementById(
            "message"
        );


    if (!message) {

        alert(texte);

        return;
    }


    message.textContent =
        texte;


    message.className =
        "message " +
        type;


    message.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

}


/* ============================================================
   HELPERS
============================================================ */

function lireTableau(cle) {

    try {

        const valeur =
            localStorage.getItem(
                cle
            );


        if (!valeur) return [];


        const resultat =
            JSON.parse(
                valeur
            );


        return Array.isArray(
            resultat
        )
            ? resultat
            : [];

    } catch (erreur) {

        console.error(
            "Erreur localStorage:",
            erreur
        );

        return [];

    }

}


function genererID() {

    return (
        Date.now().toString(36) +
        Math.random()
            .toString(36)
            .substring(2, 8)
    );

}


function getValue(id) {

    const element =
        document.getElementById(id);


    return element
        ? element.value || ""
        : "";

}


function setValue(
    id,
    valeur
) {

    const element =
        document.getElementById(id);


    if (element) {

        element.value =
            valeur ?? "";

    }

}


function escapeHTML(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}