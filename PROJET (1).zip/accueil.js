// ========================================
// BURUNDI PEOPLE REGISTRY
// ACCUEIL.JS
// ========================================


// ========================================
// INITIALISATION
// ========================================

document.addEventListener("DOMContentLoaded", function () {

    afficherUtilisateur();

    afficherStatistiques();

    gererAccesManager();

    verifierSynchronisation();

});


// ========================================
// UTILISATEUR CONNECTÉ
// ========================================

function afficherUtilisateur() {

    const username =
        localStorage.getItem("username");

    const userRole =
        localStorage.getItem("userRole");

    const nom =
        document.getElementById("nomUtilisateurAccueil");

    const role =
        document.getElementById("roleUtilisateur");

    if (nom) {

        nom.textContent =
            username || "Utilisateur";

    }

    if (role) {

        if (userRole === "manager") {

            role.textContent = "Manager";

        } else {

            role.textContent = "Utilisateur";

        }

    }

}


// ========================================
// RÉCUPÉRER LES PERSONNES
// ========================================

function getPersonnes() {

    return JSON.parse(
        localStorage.getItem("people") || "[]"
    );

}


// ========================================
// RÉCUPÉRER LES MÉNAGES
// ========================================

function getMenages() {

    return JSON.parse(
        localStorage.getItem("menages") || "[]"
    );

}


// ========================================
// STATISTIQUES
// ========================================

function afficherStatistiques() {

    const personnes =
        getPersonnes();

    const menages =
        getMenages();


    const personnesElement =
        document.getElementById(
            "totalPersonnes"
        );

    const menagesElement =
        document.getElementById(
            "totalMenages"
        );


    if (personnesElement) {

        personnesElement.textContent =
            personnes.length;

    }


    if (menagesElement) {

        menagesElement.textContent =
            menages.length;

    }

}


// ========================================
// ACCÈS MANAGER
// ========================================

function gererAccesManager() {

    const role =
        localStorage.getItem("userRole");

    const managerLinks =
        document.querySelectorAll(
            ".manager-only"
        );


    managerLinks.forEach(function (element) {

        if (role !== "manager") {

            element.style.display =
                "none";

        } else {

            element.style.display =
                "";

        }

    });

}


// ========================================
// SYNCHRONISATION
// ========================================

function synchroniser() {

    const role =
        localStorage.getItem("userRole");


    if (role === "manager") {

        afficherMessage(
            "Vous êtes déjà dans le compte Manager."
        );

        return;

    }


    /*
       Pour cette version locale,
       on marque simplement les données
       comme synchronisées.
    */

    const personnes =
        getPersonnes();

    const menages =
        getMenages();


    localStorage.setItem(
        "derniereSynchronisation",
        new Date().toLocaleString("fr-FR")
    );


    localStorage.setItem(
        "synchronisationDemandee",
        "true"
    );


    localStorage.setItem(
        "syncPersonnes",
        JSON.stringify(personnes)
    );


    localStorage.setItem(
        "syncMenages",
        JSON.stringify(menages)
    );


    afficherMessage(
        "Synchronisation effectuée avec succès."
    );


    verifierSynchronisation();

}


// ========================================
// AFFICHER ÉTAT SYNCHRONISATION
// ========================================

function verifierSynchronisation() {

    const element =
        document.getElementById(
            "syncStatus"
        );


    if (!element) return;


    const date =
        localStorage.getItem(
            "derniereSynchronisation"
        );


    if (date) {

        element.textContent =
            "✓ Dernière synchronisation : " +
            date;

    } else {

        element.textContent =
            "⚠ Aucune synchronisation effectuée";

    }

}


// ========================================
// MESSAGE
// ========================================

function afficherMessage(texte) {

    const message =
        document.getElementById(
            "messageAccueil"
        );


    if (!message) {

        alert(texte);

        return;

    }


    message.textContent =
        texte;


    message.style.display =
        "block";


    setTimeout(function () {

        message.style.display =
            "none";

    }, 3000);

}


// ========================================
// EXPORT CSV
// ========================================

function telechargerCSV() {

    const personnes =
        getPersonnes();


    if (personnes.length === 0) {

        alert(
            "Aucune personne enregistrée."
        );

        return;

    }


    const colonnes = [

        "Nom",
        "Prénom",
        "Sexe",
        "Date de naissance",
        "Identité",
        "Téléphone",
        "Pays",
        "Province",
        "Commune",
        "Zone",
        "Colline",
        "Sous-colline"

    ];


    let csv =
        colonnes.join(";") +
        "\n";


    personnes.forEach(function (p) {

        const ligne = [

            p.nom || "",
            p.prenom || "",
            p.sexe || "",
            p.dateNaissance || "",
            p.identite || "",
            p.telephone || "",
            p.pays || "Burundi",
            p.province || "",
            p.commune || "",
            p.zone || "",
            p.colline || "",
            p.sousColline || ""

        ];


        csv +=
            ligne
            .map(function (valeur) {

                return '"' +
                    String(valeur)
                    .replace(/"/g, '""') +
                    '"';

            })
            .join(";") +
            "\n";

    });


    const blob =
        new Blob(
            ["\ufeff" + csv],
            {
                type:
                    "text/csv;charset=utf-8;"
            }
        );


    const url =
        URL.createObjectURL(blob);


    const lien =
        document.createElement("a");


    lien.href =
        url;


    lien.download =
        "personnes-enregistrees.csv";


    document.body.appendChild(lien);


    lien.click();


    document.body.removeChild(lien);


    URL.revokeObjectURL(url);

}


// ========================================
// EXPORT PDF
// ========================================

function telechargerPDF() {

    const personnes =
        getPersonnes();


    if (personnes.length === 0) {

        alert(
            "Aucune personne enregistrée."
        );

        return;

    }


    /*
       Vérifie si jsPDF est disponible.
    */

    if (
        typeof window.jspdf ===
        "undefined"
    ) {

        alert(
            "La bibliothèque PDF n'est pas encore installée."
        );

        return;

    }


    const {
        jsPDF
    } = window.jspdf;


    const doc =
        new jsPDF(
            "landscape"
        );


    doc.setFontSize(16);


    doc.text(
        "BURUNDI PEOPLE REGISTRY",
        14,
        15
    );


    doc.setFontSize(10);


    doc.text(
        "Liste des personnes enregistrées",
        14,
        23
    );


    let y = 32;


    personnes.forEach(
        function (p, index) {

            const texte =

                (index + 1) +
                ". " +

                (p.nom || "") +
                " " +

                (p.prenom || "") +

                " | " +

                (p.sexe || "") +

                " | " +

                (p.province || "") +

                " | " +

                (p.commune || "") +

                " | " +

                (p.zone || "") +

                " | " +

                (p.colline || "");


            doc.text(
                texte.substring(
                    0,
                    150
                ),
                14,
                y
            );


            y += 7;


            if (y > 190) {

                doc.addPage();

                y = 20;

            }

        }
    );


    doc.save(
        "personnes-enregistrees.pdf"
    );

}


// ========================================
// RECHERCHE MÉNAGES
// ========================================

function rechercherMenage() {

    const input =
        document.getElementById(
            "rechercheMenage"
        );


    const recherche =
        input
        ? input.value
            .toLowerCase()
            .trim()
        : "";


    const menages =
        getMenages();


    const resultat =
        menages.filter(
            function (m) {

                const texte =

                    JSON.stringify(m)
                    .toLowerCase();


                return texte.includes(
                    recherche
                );

            }
        );


    /*
       Si la page contient une fonction
       d'affichage des ménages,
       on l'utilise.
    */

    if (
        typeof afficherMenages ===
        "function"
    ) {

        afficherMenages(
            resultat
        );

    }

}


// ========================================
// RECHERCHE PERSONNES
// ========================================

function rechercherPersonnes() {

    const input =
        document.getElementById(
            "recherchePersonnes"
        );


    if (!input) return;


    const recherche =
        input.value
            .toLowerCase()
            .trim();


    const personnes =
        getPersonnes();


    const resultat =
        personnes.filter(
            function (p) {

                const texte =

                    JSON.stringify(p)
                    .toLowerCase();


                return texte.includes(
                    recherche
                );

            }
        );


    if (
        typeof afficherPersonnes ===
        "function"
    ) {

        afficherPersonnes(
            resultat
        );

    }

}


// ========================================
// DÉCONNEXION
// ========================================

function deconnexion() {

    const confirmation =
        confirm(
            "Voulez-vous vous déconnecter ?"
        );


    if (!confirmation) return;


    localStorage.removeItem(
        "isLoggedIn"
    );

    localStorage.removeItem(
        "userRole"
    );

    localStorage.removeItem(
        "username"
    );


    window.location.href =
        "index.html";

}


// ========================================
// BOUTON DÉCONNEXION
// ========================================

const btnLogout =
    document.getElementById(
        "btnLogout"
    );


if (btnLogout) {

    btnLogout.addEventListener(
        "click",
        deconnexion
    );

}