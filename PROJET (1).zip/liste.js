/* =========================================================
   BURUNDI PEOPLE REGISTRY
   LISTE.JS

   - Liste des ménages
   - Liste des personnes enregistrées
   - Les deux listes sont séparées
   - Les visiteurs ne sont PAS affichés dans les personnes
   ========================================================= */

const MENAGES_KEY = "bpr_menages";
const PERSONNES_KEY = "bpr_personnes";
const VISITEURS_KEY = "bpr_visiteurs";

let tousLesMenages = [];
let tousLesPersonnes = [];

let menagesFiltres = [];
let personnesFiltrees = [];


/* =========================================================
   INITIALISATION
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initialiser();

});


function initialiser() {

    chargerDonnees();

    initialiserTabs();

    initialiserRechercheMenages();

    initialiserRecherchePersonnes();

    initialiserFiltresPersonnes();

    initialiserBoutons();

    afficherMenages();

    afficherPersonnes();

    protegerManager();

}


/* =========================================================
   LECTURE LOCALSTORAGE
========================================================= */

function lireStorage(cle) {

    try {

        const donnees = localStorage.getItem(cle);

        if (!donnees) {
            return [];
        }

        const resultat = JSON.parse(donnees);

        return Array.isArray(resultat) ? resultat : [];

    } catch (erreur) {

        console.error(
            "Erreur lecture localStorage :",
            cle,
            erreur
        );

        return [];

    }

}


/* =========================================================
   CHARGEMENT DES DONNÉES
========================================================= */

function chargerDonnees() {

    /*
     * IMPORTANT :
     * Les ménages viennent UNIQUEMENT de bpr_menages.
     */

    tousLesMenages = lireStorage(MENAGES_KEY);

    /*
     * Les personnes viennent UNIQUEMENT de bpr_personnes.
     */

    tousLesPersonnes = lireStorage(PERSONNES_KEY);

    /*
     * Les visiteurs ne sont volontairement pas chargés
     * dans la liste des personnes.
     */

    menagesFiltres = [...tousLesMenages];

    personnesFiltrees = [...tousLesPersonnes];

}


/* =========================================================
   OUTILS
========================================================= */

function valeur(objet, ...cles) {

    for (const cle of cles) {

        if (
            objet &&
            objet[cle] !== undefined &&
            objet[cle] !== null &&
            String(objet[cle]).trim() !== ""
        ) {

            return String(objet[cle]);

        }

    }

    return "";

}


function normaliser(texte) {

    return String(texte || "")
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .trim();

}


function echapperHTML(texte) {

    return String(texte ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* =========================================================
   TABS
========================================================= */

function initialiserTabs() {

    const btnListeMenages =
        document.getElementById("btnListeMenages");

    const btnListePersonnes =
        document.getElementById("btnListePersonnes");

    const sectionMenages =
        document.getElementById("sectionMenages");

    const sectionPersonnes =
        document.getElementById("sectionPersonnes");


    if (!btnListeMenages || !btnListePersonnes) {
        return;
    }


    btnListeMenages.addEventListener("click", () => {

        sectionMenages.classList.remove("hidden");
        sectionPersonnes.classList.add("hidden");

        btnListeMenages.classList.add("active");
        btnListePersonnes.classList.remove("active");

        afficherMenages();

    });


    btnListePersonnes.addEventListener("click", () => {

        sectionPersonnes.classList.remove("hidden");
        sectionMenages.classList.add("hidden");

        btnListePersonnes.classList.add("active");
        btnListeMenages.classList.remove("active");

        afficherPersonnes();

    });

}


/* =========================================================
   LISTE DES MÉNAGES
========================================================= */

function afficherMenages(liste = menagesFiltres) {

    const tableau =
        document.getElementById("tableauMenages");

    const compteur =
        document.getElementById("nombreMenages");


    if (!tableau) {
        return;
    }


    if (compteur) {
        compteur.textContent = liste.length;
    }


    if (liste.length === 0) {

        tableau.innerHTML = `
            <tr>
                <td colspan="9" class="empty">
                    Aucun ménage enregistré.
                </td>
            </tr>
        `;

        return;

    }


    tableau.innerHTML = "";


    liste.forEach((menage, index) => {

        const id = valeur(menage, "id");

        const chefMenage = valeur(
            menage,
            "chefMenage",
            "nomPere",
            "nomChefMenage"
        );

        const province = valeur(
            menage,
            "province"
        );

        const commune = valeur(
            menage,
            "commune"
        );

        const zone = valeur(
            menage,
            "zone"
        );

        const colline = valeur(
            menage,
            "colline"
        );

        const sousColline = valeur(
            menage,
            "sousColline",
            "sous-colline"
        );

        const chef10 = valeur(
            menage,
            "chef10Maisons",
            "chef10"
        );


        const ligne = document.createElement("tr");


        ligne.innerHTML = `

            <td>${index + 1}</td>

            <td>
                ${echapperHTML(chefMenage)}
            </td>

            <td>
                ${echapperHTML(province)}
            </td>

            <td>
                ${echapperHTML(commune)}
            </td>

            <td>
                ${echapperHTML(zone)}
            </td>

            <td>
                ${echapperHTML(colline)}
            </td>

            <td>
                ${echapperHTML(sousColline)}
            </td>

            <td>
                ${echapperHTML(chef10)}
            </td>

            <td>

                <button
                    type="button"
                    onclick="voirMenage('${safeJS(id)}')"
                >
                    👁️ Voir
                </button>

                <button
                    type="button"
                    onclick="modifierMenage('${safeJS(id)}')"
                >
                    ✏️ Modifier
                </button>

                <button
                    type="button"
                    onclick="supprimerMenage('${safeJS(id)}')"
                >
                    🗑️ Supprimer
                </button>

            </td>
        `;


        tableau.appendChild(ligne);

    });

}


/* =========================================================
   RECHERCHE MÉNAGES
========================================================= */

function initialiserRechercheMenages() {

    const recherche =
        document.getElementById("rechercheMenage");


    if (!recherche) {
        return;
    }


    recherche.addEventListener("input", appliquerRechercheMenage);

}


function appliquerRechercheMenage() {

    const recherche =
        document.getElementById("rechercheMenage");

    const terme =
        normaliser(recherche?.value || "");


    if (!terme) {

        menagesFiltres = [...tousLesMenages];

        afficherMenages();

        return;

    }


    menagesFiltres = tousLesMenages.filter(menage => {

        const texte = [

            valeur(menage, "chefMenage"),
            valeur(menage, "nomPere"),
            valeur(menage, "province"),
            valeur(menage, "commune"),
            valeur(menage, "zone"),
            valeur(menage, "colline"),
            valeur(menage, "sousColline"),
            valeur(menage, "chef10Maisons"),
            valeur(menage, "chef10"),
            valeur(menage, "pays")

        ].join(" ");


        return normaliser(texte).includes(terme);

    });


    afficherMenages();

}


/* =========================================================
   VOIR MÉNAGE
========================================================= */

function voirMenage(id) {

    if (!id) {
        return;
    }

    localStorage.setItem(
        "bpr_menage_selectionne",
        id
    );

    window.location.href =
        "voir-menage.html?id=" +
        encodeURIComponent(id);

}


/* =========================================================
   MODIFIER MÉNAGE
========================================================= */

function modifierMenage(id) {

    if (!id) {
        return;
    }


    localStorage.setItem(
        "bpr_menage_a_modifier",
        id
    );


    window.location.href =
        "register.html?edit=" +
        encodeURIComponent(id);

}


/* =========================================================
   SUPPRIMER MÉNAGE
========================================================= */

function supprimerMenage(id) {

    if (!id) {
        return;
    }


    const confirmation = confirm(
        "Voulez-vous vraiment supprimer ce ménage ?\n\n" +
        "Les personnes appartenant à ce ménage seront également supprimées."
    );


    if (!confirmation) {
        return;
    }


    /*
     * SUPPRESSION DU MÉNAGE
     */

    tousLesMenages =
        tousLesMenages.filter(
            menage =>
                String(menage.id) !== String(id)
        );


    localStorage.setItem(
        MENAGES_KEY,
        JSON.stringify(tousLesMenages)
    );


    /*
     * SUPPRESSION DES PERSONNES LIÉES AU MÉNAGE
     */

    let personnes =
        lireStorage(PERSONNES_KEY);


    personnes =
        personnes.filter(personne => {

            const personneMenageId =
                valeur(
                    personne,
                    "menageId",
                    "idMenage"
                );


            return String(personneMenageId) !==
                   String(id);

        });


    localStorage.setItem(
        PERSONNES_KEY,
        JSON.stringify(personnes)
    );


    /*
     * SUPPRESSION DES VISITEURS DU MÉNAGE
     */

    let visiteurs =
        lireStorage(VISITEURS_KEY);


    visiteurs =
        visiteurs.filter(visiteur => {

            const visiteurMenageId =
                valeur(
                    visiteur,
                    "menageId",
                    "idMenage"
                );


            return String(visiteurMenageId) !==
                   String(id);

        });


    localStorage.setItem(
        VISITEURS_KEY,
        JSON.stringify(visiteurs)
    );


    /*
     * RECHARGEMENT
     */

    chargerDonnees();

    afficherMenages();

    afficherPersonnes();


    alert(
        "Le ménage et ses personnes associées ont été supprimés."
    );

}


/* =========================================================
   LISTE DES PERSONNES
========================================================= */

function afficherPersonnes(liste = personnesFiltrees) {

    const tableau =
        document.getElementById("tableauPersonnes");

    const compteur =
        document.getElementById("nombrePersonnes");


    if (!tableau) {
        return;
    }


    if (compteur) {
        compteur.textContent = liste.length;
    }


    if (liste.length === 0) {

        tableau.innerHTML = `
            <tr>
                <td colspan="9" class="empty">
                    Aucune personne enregistrée.
                </td>
            </tr>
        `;

        return;

    }


    tableau.innerHTML = "";


    liste.forEach((personne, index) => {

        const nom = valeur(
            personne,
            "nomPrenom",
            "nom",
            "nomComplet"
        );


        /*
         * register.js utilise "sexe" pour père/mère
         * et "Genre" pour enfants/parentés.
         */

        const sexe = valeur(
            personne,
            "sexe",
            "Genre",
            "genre"
        );


        const province = valeur(
            personne,
            "province"
        );

        const commune = valeur(
            personne,
            "commune"
        );

        const zone = valeur(
            personne,
            "zone"
        );

        const colline = valeur(
            personne,
            "colline"
        );

        const sousColline = valeur(
            personne,
            "sousColline",
            "sous-colline"
        );

        const chef10 = valeur(
            personne,
            "chef10Maisons",
            "chef10"
        );


        /*
         * IMPORTANT :
         * On n'affiche PAS :
         * - type
         * - lien de parenté
         * - ménage d'origine
         * - visiteurs
         *
         * La table reste exactement comme dans le HTML.
         */

        const ligne = document.createElement("tr");


        ligne.innerHTML = `

            <td>${index + 1}</td>

            <td>
                ${echapperHTML(nom)}
            </td>

            <td>
                ${echapperHTML(sexe)}
            </td>

            <td>
                ${echapperHTML(province)}
            </td>

            <td>
                ${echapperHTML(commune)}
            </td>

            <td>
                ${echapperHTML(zone)}
            </td>

            <td>
                ${echapperHTML(colline)}
            </td>

            <td>
                ${echapperHTML(sousColline)}
            </td>

            <td>
                ${echapperHTML(chef10)}
            </td>

        `;


        tableau.appendChild(ligne);

    });

}


/* =========================================================
   RECHERCHE PERSONNES
========================================================= */

function initialiserRecherchePersonnes() {

    const recherche =
        document.getElementById("recherchePersonne");


    if (!recherche) {
        return;
    }


    recherche.addEventListener(
        "input",
        appliquerFiltresPersonnes
    );

}


/* =========================================================
   FILTRES PERSONNES
========================================================= */

function initialiserFiltresPersonnes() {

    const ids = [

        "filtrePays",
        "filtreProvince",
        "filtreCommune",
        "filtreZone",
        "filtreColline",
        "filtreSousColline",
        "filtreChef10Maisons"

    ];


    ids.forEach(id => {

        const element =
            document.getElementById(id);


        if (element) {

            element.addEventListener(
                "change",
                appliquerFiltresPersonnes
            );

        }

    });


    const btnAppliquer =
        document.getElementById(
            "btnAppliquerFiltres"
        );


    if (btnAppliquer) {

        btnAppliquer.addEventListener(
            "click",
            appliquerFiltresPersonnes
        );

    }


    const btnReset =
        document.getElementById(
            "btnResetFiltres"
        );


    if (btnReset) {

        btnReset.addEventListener(
            "click",
            resetFiltresPersonnes
        );

    }


    remplirProvincesPersonnes();

}


/* =========================================================
   PROVINCES
========================================================= */

function remplirProvincesPersonnes() {

    const select =
        document.getElementById(
            "filtreProvince"
        );


    if (!select) {
        return;
    }


    const provinces = [];


    tousLesPersonnes.forEach(personne => {

        const province =
            valeur(personne, "province");


        if (
            province &&
            !provinces.some(
                p =>
                    normaliser(p) ===
                    normaliser(province)
            )
        ) {

            provinces.push(province);

        }

    });


    /*
     * Les provinces déjà présentes dans HTML
     * sont conservées.
     */

    const valeursExistantes =
        Array.from(select.options)
            .map(option => option.value)
            .filter(Boolean);


    provinces.forEach(province => {

        const existe =
            valeursExistantes.some(
                p =>
                    normaliser(p) ===
                    normaliser(province)
            );


        if (!existe) {

            const option =
                document.createElement("option");

            option.value = province;
            option.textContent = province;

            select.appendChild(option);

        }

    });


    select.addEventListener(
        "change",
        () => {

            remplirCommunesPersonnes();

            viderSelect(
                "filtreZone",
                "Toutes les zones"
            );

            viderSelect(
                "filtreColline",
                "Toutes les collines"
            );

            viderSelect(
                "filtreSousColline",
                "Toutes les sous-collines"
            );

            remplirChefs10Personnes();

        }
    );


    remplirCommunesPersonnes();

}


/* =========================================================
   COMMUNES
========================================================= */

function remplirCommunesPersonnes() {

    const selectCommune =
        document.getElementById(
            "filtreCommune"
        );


    if (!selectCommune) {
        return;
    }


    const province =
        document.getElementById(
            "filtreProvince"
        )?.value || "";


    viderSelect(
        "filtreCommune",
        "Toutes les communes"
    );


    const communes = [];


    tousLesPersonnes.forEach(personne => {

        const personneProvince =
            valeur(personne, "province");

        const commune =
            valeur(personne, "commune");


        if (
            commune &&
            (
                !province ||
                normaliser(personneProvince) ===
                normaliser(province)
            )
        ) {

            if (
                !communes.some(
                    c =>
                        normaliser(c) ===
                        normaliser(commune)
                )
            ) {

                communes.push(commune);

            }

        }

    });


    communes.sort((a, b) =>
        a.localeCompare(b)
    );


    communes.forEach(commune => {

        const option =
            document.createElement("option");

        option.value = commune;
        option.textContent = commune;

        selectCommune.appendChild(option);

    });


    selectCommune.onchange =
        remplirZonesPersonnes;


    remplirZonesPersonnes();

}


/* =========================================================
   ZONES
========================================================= */

function remplirZonesPersonnes() {

    const province =
        document.getElementById(
            "filtreProvince"
        )?.value || "";


    const commune =
        document.getElementById(
            "filtreCommune"
        )?.value || "";


    viderSelect(
        "filtreZone",
        "Toutes les zones"
    );


    const zones = [];


    tousLesPersonnes.forEach(personne => {

        const p =
            valeur(personne, "province");

        const c =
            valeur(personne, "commune");

        const z =
            valeur(personne, "zone");


        if (
            z &&
            (
                !province ||
                normaliser(p) ===
                normaliser(province)
            ) &&
            (
                !commune ||
                normaliser(c) ===
                normaliser(commune)
            )
        ) {

            if (
                !zones.some(
                    zone =>
                        normaliser(zone) ===
                        normaliser(z)
                )
            ) {

                zones.push(z);

            }

        }

    });


    zones.sort((a, b) =>
        a.localeCompare(b)
    );


    const select =
        document.getElementById(
            "filtreZone"
        );


    zones.forEach(zone => {

        const option =
            document.createElement("option");

        option.value = zone;
        option.textContent = zone;

        select.appendChild(option);

    });


    select.onchange =
        remplirCollinesPersonnes;


    remplirCollinesPersonnes();

}


/* =========================================================
   COLLINES
========================================================= */

function remplirCollinesPersonnes() {

    const province =
        document.getElementById(
            "filtreProvince"
        )?.value || "";


    const commune =
        document.getElementById(
            "filtreCommune"
        )?.value || "";


    const zone =
        document.getElementById(
            "filtreZone"
        )?.value || "";


    viderSelect(
        "filtreColline",
        "Toutes les collines"
    );


    const collines = [];


    tousLesPersonnes.forEach(personne => {

        const p =
            valeur(personne, "province");

        const c =
            valeur(personne, "commune");

        const z =
            valeur(personne, "zone");

        const col =
            valeur(personne, "colline");


        if (
            col &&
            (
                !province ||
                normaliser(p) ===
                normaliser(province)
            ) &&
            (
                !commune ||
                normaliser(c) ===
                normaliser(commune)
            ) &&
            (
                !zone ||
                normaliser(z) ===
                normaliser(zone)
            )
        ) {

            if (
                !collines.some(
                    item =>
                        normaliser(item) ===
                        normaliser(col)
                )
            ) {

                collines.push(col);

            }

        }

    });


    collines.sort((a, b) =>
        a.localeCompare(b)
    );


    const select =
        document.getElementById(
            "filtreColline"
        );


    collines.forEach(colline => {

        const option =
            document.createElement("option");

        option.value = colline;
        option.textContent = colline;

        select.appendChild(option);

    });


    select.onchange =
        remplirSousCollinesPersonnes;


    remplirSousCollinesPersonnes();

}


/* =========================================================
   SOUS-COLLINES
========================================================= */

function remplirSousCollinesPersonnes() {

    const province =
        document.getElementById(
            "filtreProvince"
        )?.value || "";


    const commune =
        document.getElementById(
            "filtreCommune"
        )?.value || "";


    const zone =
        document.getElementById(
            "filtreZone"
        )?.value || "";


    const colline =
        document.getElementById(
            "filtreColline"
        )?.value || "";


    viderSelect(
        "filtreSousColline",
        "Toutes les sous-collines"
    );


    const sousCollines = [];


    tousLesPersonnes.forEach(personne => {

        const p =
            valeur(personne, "province");

        const c =
            valeur(personne, "commune");

        const z =
            valeur(personne, "zone");

        const col =
            valeur(personne, "colline");

        const sous =
            valeur(
                personne,
                "sousColline",
                "sous-colline"
            );


        if (
            sous &&
            (
                !province ||
                normaliser(p) ===
                normaliser(province)
            ) &&
            (
                !commune ||
                normaliser(c) ===
                normaliser(commune)
            ) &&
            (
                !zone ||
                normaliser(z) ===
                normaliser(zone)
            ) &&
            (
                !colline ||
                normaliser(col) ===
                normaliser(colline)
            )
        ) {

            if (
                !sousCollines.some(
                    item =>
                        normaliser(item) ===
                        normaliser(sous)
                )
            ) {

                sousCollines.push(sous);

            }

        }

    });


    sousCollines.sort((a, b) =>
        a.localeCompare(b)
    );


    const select =
        document.getElementById(
            "filtreSousColline"
        );


    sousCollines.forEach(sous => {

        const option =
            document.createElement("option");

        option.value = sous;
        option.textContent = sous;

        select.appendChild(option);

    });


    select.onchange =
        remplirChefs10Personnes;


    remplirChefs10Personnes();

}


/* =========================================================
   CHEF DE 10 MAISONS
========================================================= */

function remplirChefs10Personnes() {

    const province =
        document.getElementById(
            "filtreProvince"
        )?.value || "";


    const commune =
        document.getElementById(
            "filtreCommune"
        )?.value || "";


    const zone =
        document.getElementById(
            "filtreZone"
        )?.value || "";


    const colline =
        document.getElementById(
            "filtreColline"
        )?.value || "";


    const sousColline =
        document.getElementById(
            "filtreSousColline"
        )?.value || "";


    viderSelect(
        "filtreChef10Maisons",
        "Tous les chefs de 10 maisons"
    );


    const chefs = [];


    tousLesPersonnes.forEach(personne => {

        const p =
            valeur(personne, "province");

        const c =
            valeur(personne, "commune");

        const z =
            valeur(personne, "zone");

        const col =
            valeur(personne, "colline");

        const sous =
            valeur(
                personne,
                "sousColline",
                "sous-colline"
            );

        const chef =
            valeur(
                personne,
                "chef10Maisons",
                "chef10"
            );


        if (
            chef &&
            (
                !province ||
                normaliser(p) ===
                normaliser(province)
            ) &&
            (
                !commune ||
                normaliser(c) ===
                normaliser(commune)
            ) &&
            (
                !zone ||
                normaliser(z) ===
                normaliser(zone)
            ) &&
            (
                !colline ||
                normaliser(col) ===
                normaliser(colline)
            ) &&
            (
                !sousColline ||
                normaliser(sous) ===
                normaliser(sousColline)
            )
        ) {

            if (
                !chefs.some(
                    item =>
                        normaliser(item) ===
                        normaliser(chef)
                )
            ) {

                chefs.push(chef);

            }

        }

    });


    chefs.sort((a, b) =>
        a.localeCompare(b)
    );


    const select =
        document.getElementById(
            "filtreChef10Maisons"
        );


    chefs.forEach(chef => {

        const option =
            document.createElement("option");

        option.value = chef;
        option.textContent = chef;

        select.appendChild(option);

    });

}


/* =========================================================
   APPLICATION DES FILTRES PERSONNES
========================================================= */

function appliquerFiltresPersonnes() {

    const recherche =
        normaliser(
            document.getElementById(
                "recherchePersonne"
            )?.value || ""
        );


    const pays =
        normaliser(
            document.getElementById(
                "filtrePays"
            )?.value || ""
        );


    const province =
        normaliser(
            document.getElementById(
                "filtreProvince"
            )?.value || ""
        );


    const commune =
        normaliser(
            document.getElementById(
                "filtreCommune"
            )?.value || ""
        );


    const zone =
        normaliser(
            document.getElementById(
                "filtreZone"
            )?.value || ""
        );


    const colline =
        normaliser(
            document.getElementById(
                "filtreColline"
            )?.value || ""
        );


    const sousColline =
        normaliser(
            document.getElementById(
                "filtreSousColline"
            )?.value || ""
        );


    const chef10 =
        normaliser(
            document.getElementById(
                "filtreChef10Maisons"
            )?.value || ""
        );


    personnesFiltrees =
        tousLesPersonnes.filter(personne => {


            const personnePays =
                normaliser(
                    valeur(
                        personne,
                        "pays"
                    ) || "Burundi"
                );


            const personneProvince =
                normaliser(
                    valeur(
                        personne,
                        "province"
                    )
                );


            const personneCommune =
                normaliser(
                    valeur(
                        personne,
                        "commune"
                    )
                );


            const personneZone =
                normaliser(
                    valeur(
                        personne,
                        "zone"
                    )
                );


            const personneColline =
                normaliser(
                    valeur(
                        personne,
                        "colline"
                    )
                );


            const personneSousColline =
                normaliser(
                    valeur(
                        personne,
                        "sousColline",
                        "sous-colline"
                    )
                );


            const personneChef10 =
                normaliser(
                    valeur(
                        personne,
                        "chef10Maisons",
                        "chef10"
                    )
                );


            const nom =
                normaliser(
                    valeur(
                        personne,
                        "nomPrenom",
                        "nom",
                        "nomComplet"
                    )
                );


            const sexe =
                normaliser(
                    valeur(
                        personne,
                        "sexe",
                        "Genre",
                        "genre"
                    )
                );


            const rechercheTexte = [

                nom,
                sexe,
                personnePays,
                personneProvince,
                personneCommune,
                personneZone,
                personneColline,
                personneSousColline,
                personneChef10

            ].join(" ");


            return (

                (!recherche ||
                 rechercheTexte.includes(recherche))

                &&

                (!pays ||
                 personnePays === pays)

                &&

                (!province ||
                 personneProvince === province)

                &&

                (!commune ||
                 personneCommune === commune)

                &&

                (!zone ||
                 personneZone === zone)

                &&

                (!colline ||
                 personneColline === colline)

                &&

                (!sousColline ||
                 personneSousColline === sousColline)

                &&

                (!chef10 ||
                 personneChef10 === chef10)

            );

        });


    afficherPersonnes(personnesFiltrees);

}


/* =========================================================
   RÉINITIALISER FILTRES PERSONNES
========================================================= */

function resetFiltresPersonnes() {

    const ids = [

        "recherchePersonne",
        "filtrePays",
        "filtreProvince",
        "filtreCommune",
        "filtreZone",
        "filtreColline",
        "filtreSousColline",
        "filtreChef10Maisons"

    ];


    ids.forEach(id => {

        const element =
            document.getElementById(id);


        if (element) {

            element.value = "";

        }

    });


    remplirCommunesPersonnes();

    personnesFiltrees =
        [...tousLesPersonnes];


    afficherPersonnes();

}


/* =========================================================
   VIDER SELECT
========================================================= */

function viderSelect(id, texte) {

    const select =
        document.getElementById(id);


    if (!select) {
        return;
    }


    select.innerHTML = "";


    const option =
        document.createElement("option");

    option.value = "";
    option.textContent = texte;


    select.appendChild(option);

}


/* =========================================================
   BOUTONS
========================================================= */

function initialiserBoutons() {


    const btnActualiserMenages =
        document.getElementById(
            "btnActualiserMenages"
        );


    if (btnActualiserMenages) {

        btnActualiserMenages.addEventListener(
            "click",
            () => {

                chargerDonnees();

                afficherMenages();

            }
        );

    }


    const btnActualiserPersonnes =
        document.getElementById(
            "btnActualiserPersonnes"
        );


    if (btnActualiserPersonnes) {

        btnActualiserPersonnes.addEventListener(
            "click",
            () => {

                chargerDonnees();

                remplirProvincesPersonnes();

                afficherPersonnes();

            }
        );

    }


    const btnCSVMenages =
        document.getElementById(
            "btnCSVMenages"
        );


    if (btnCSVMenages) {

        btnCSVMenages.addEventListener(
            "click",
            exporterMenagesCSV
        );

    }


    const btnPDFMenages =
        document.getElementById(
            "btnPDFMenages"
        );


    if (btnPDFMenages) {

        btnPDFMenages.addEventListener(
            "click",
            exporterMenagesPDF
        );

    }


    const btnCSVPersonnes =
        document.getElementById(
            "btnCSVPersonnes"
        );


    if (btnCSVPersonnes) {

        btnCSVPersonnes.addEventListener(
            "click",
            exporterPersonnesCSV
        );

    }


    const btnPDFPersonnes =
        document.getElementById(
            "btnPDFPersonnes"
        );


    if (btnPDFPersonnes) {

        btnPDFPersonnes.addEventListener(
            "click",
            exporterPersonnesPDF
        );

    }


    const btnDeconnexion =
        document.getElementById(
            "btnDeconnexion"
        );


    if (btnDeconnexion) {

        btnDeconnexion.addEventListener(
            "click",
            deconnexion
        );

    }

}


/* =========================================================
   CSV MÉNAGES
========================================================= */

function exporterMenagesCSV() {

    if (!menagesFiltres.length) {

        alert(
            "Aucun ménage à exporter."
        );

        return;

    }


    const lignes = [

        [
            "N°",
            "Chef de ménage",
            "Pays",
            "Province",
            "Commune",
            "Zone",
            "Colline",
            "Sous-colline",
            "Chef de 10 maisons"
        ]

    ];


    menagesFiltres.forEach((menage, index) => {

        lignes.push([

            index + 1,

            valeur(
                menage,
                "chefMenage",
                "nomPere"
            ),

            valeur(
                menage,
                "pays"
            ),

            valeur(
                menage,
                "province"
            ),

            valeur(
                menage,
                "commune"
            ),

            valeur(
                menage,
                "zone"
            ),

            valeur(
                menage,
                "colline"
            ),

            valeur(
                menage,
                "sousColline"
            ),

            valeur(
                menage,
                "chef10Maisons"
            )

        ]);

    });


    telechargerCSV(
        lignes,
        "liste_menages.csv"
    );

}


/* =========================================================
   CSV PERSONNES
========================================================= */

function exporterPersonnesCSV() {

    if (!personnesFiltrees.length) {

        alert(
            "Aucune personne à exporter."
        );

        return;

    }


    const lignes = [

        [
            "N°",
            "Nom et prénom",
            "Sexe",
            "Province",
            "Commune",
            "Zone",
            "Colline",
            "Sous-colline",
            "Chef de 10 maisons"
        ]

    ];


    personnesFiltrees.forEach((personne, index) => {

        lignes.push([

            index + 1,

            valeur(
                personne,
                "nomPrenom",
                "nom",
                "nomComplet"
            ),

            valeur(
                personne,
                "sexe",
                "Genre",
                "genre"
            ),

            valeur(
                personne,
                "province"
            ),

            valeur(
                personne,
                "commune"
            ),

            valeur(
                personne,
                "zone"
            ),

            valeur(
                personne,
                "colline"
            ),

            valeur(
                personne,
                "sousColline"
            ),

            valeur(
                personne,
                "chef10Maisons"
            )

        ]);

    });


    telechargerCSV(
        lignes,
        "liste_personnes.csv"
    );

}


/* =========================================================
   TÉLÉCHARGEMENT CSV
========================================================= */

function telechargerCSV(lignes, nomFichier) {

    const csv =
        "\uFEFF" +
        lignes
            .map(ligne =>
                ligne
                    .map(cellule =>
                        `"${String(cellule ?? "")
                            .replace(/"/g, '""')}"`
                    )
                    .join(";")
            )
            .join("\n");


    const blob =
        new Blob(
            [csv],
            {
                type:
                    "text/csv;charset=utf-8;"
            }
        );


    const url =
        URL.createObjectURL(blob);


    const lien =
        document.createElement("a");


    lien.href = url;
    lien.download = nomFichier;


    document.body.appendChild(lien);

    lien.click();

    lien.remove();


    URL.revokeObjectURL(url);

}


/* =========================================================
   PDF MÉNAGES
========================================================= */

function exporterMenagesPDF() {

    if (!menagesFiltres.length) {

        alert(
            "Aucun ménage à exporter."
        );

        return;

    }


    if (
        !window.jspdf ||
        !window.jspdf.jsPDF
    ) {

        alert(
            "La bibliothèque PDF n'est pas disponible."
        );

        return;

    }


    const { jsPDF } =
        window.jspdf;


    const doc =
        new jsPDF(
            "landscape"
        );


    doc.text(
        "BURUNDI PEOPLE REGISTRY",
        14,
        15
    );


    doc.text(
        "Liste des ménages",
        14,
        23
    );


    const donnees =
        menagesFiltres.map(
            (menage, index) => [

                index + 1,

                valeur(
                    menage,
                    "chefMenage",
                    "nomPere"
                ),

                valeur(
                    menage,
                    "province"
                ),

                valeur(
                    menage,
                    "commune"
                ),

                valeur(
                    menage,
                    "zone"
                ),

                valeur(
                    menage,
                    "colline"
                ),

                valeur(
                    menage,
                    "sousColline"
                ),

                valeur(
                    menage,
                    "chef10Maisons"
                )

            ]
        );


    doc.autoTable({

        startY: 30,

        head: [[
            "#",
            "Chef ménage",
            "Province",
            "Commune",
            "Zone",
            "Colline",
            "Sous-colline",
            "Chef 10"
        ]],

        body: donnees

    });


    doc.save(
        "liste_menages.pdf"
    );

}


/* =========================================================
   PDF PERSONNES
========================================================= */

function exporterPersonnesPDF() {

    if (!personnesFiltrees.length) {

        alert(
            "Aucune personne à exporter."
        );

        return;

    }


    if (
        !window.jspdf ||
        !window.jspdf.jsPDF
    ) {

        alert(
            "La bibliothèque PDF n'est pas disponible."
        );

        return;

    }


    const { jsPDF } =
        window.jspdf;


    const doc =
        new jsPDF(
            "landscape"
        );


    doc.text(
        "BURUNDI PEOPLE REGISTRY",
        14,
        15
    );


    doc.text(
        "Liste des personnes enregistrées",
        14,
        23
    );


    const donnees =
        personnesFiltrees.map(
            (personne, index) => [

                index + 1,

                valeur(
                    personne,
                    "nomPrenom",
                    "nom",
                    "nomComplet"
                ),

                valeur(
                    personne,
                    "sexe",
                    "Genre",
                    "genre"
                ),

                valeur(
                    personne,
                    "province"
                ),

                valeur(
                    personne,
                    "commune"
                ),

                valeur(
                    personne,
                    "zone"
                ),

                valeur(
                    personne,
                    "colline"
                ),

                valeur(
                    personne,
                    "sousColline"
                ),

                valeur(
                    personne,
                    "chef10Maisons"
                )

            ]
        );


    doc.autoTable({

        startY: 30,

        head: [[
            "#",
            "Nom et prénom",
            "Sexe",
            "Province",
            "Commune",
            "Zone",
            "Colline",
            "Sous-colline",
            "Chef 10"
        ]],

        body: donnees,

        styles: {
            fontSize: 7
        }

    });


    doc.save(
        "liste_personnes.pdf"
    );

}


/* =========================================================
   PROTECTION MANAGER
========================================================= */

function protegerManager() {

    const lienManager =
        document.getElementById(
            "lienManager"
        );


    if (!lienManager) {
        return;
    }


    const role =
        localStorage.getItem(
            "userRole"
        );


    if (
        role !== "manager" &&
        role !== "Manager"
    ) {

        lienManager.style.display =
            "none";

    }

}


/* =========================================================
   DÉCONNEXION
========================================================= */

function deconnexion() {

    const confirmation =
        confirm(
            "Voulez-vous vraiment vous déconnecter ?"
        );


    if (!confirmation) {
        return;
    }


    localStorage.removeItem(
        "userRole"
    );

    localStorage.removeItem(
        "currentUser"
    );

    localStorage.removeItem(
        "bpr_utilisateur_connecte"
    );


    window.location.href =
        "index.html";

}


/* =========================================================
   SÉCURISER ID POUR JAVASCRIPT
========================================================= */

function safeJS(value) {

    return String(value || "")
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "\\'");

}